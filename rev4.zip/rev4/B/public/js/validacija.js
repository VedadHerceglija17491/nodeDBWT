var Validacija = (function() {
    //lokalne variable idu ovdje
 
    let sveValidno = true;
    let staNijeValidno = [];
 
    // let $divElementPoruke = null;
   
    var konstruktor = function(divElementPoruke) {
 
        let $divElementPoruke = divElementPoruke;
       
        return {
             $divElementPoruke,
             sveValidno,
             staNijeValidno,
             markAsInvalid,
             ime: function(inputElement) {
                let regexIme = /^([A-Z][A-Za-z']+[- ]?){1,4}$/;
                if (!regexIme.test(inputElement.value)) {
                    this.markAsInvalid(inputElement, 'ime');
                } else {
                    inputElement.style.backgroundColor = 'white';
                }
             },
             godina: function(inputElement) {
                let godine = inputElement[inputElement.selectedIndex].value.split('/');
               
                if (godine.length > 2) {
                    this.markAsInvalid(inputElement, 'godina');
                    sveValidno = false;
                    staNijeValidno.push('ime');
                } else if (godine[0] >= 2000 && godine[0] < 2100 && godine[1] >= 2000 && godine[1] < 2100) {
                    if (godine[0] % 100 != godine[1] % 100 - 1) {
                        this.markAsInvalid(inputElement, 'godina');
                    } else {
                        inputElement.style.backgroundColor = 'white';
                    }
                } else {
                    this.markAsInvalid(inputElement, 'godina');
                }
 
             },
             repozitorij: function(inputElement, regex) {
                if (!regex) {
                    regex = /.{2,}$/;
                }
                if (typeof regex == "string") {
                    regex = new RegExp(regex, 'g');
                }
                if (!regex.test(inputElement.value)) {
                    this.markAsInvalid(inputElement, 'repozitorij');
                } else {
                    inputElement.style.backgroundColor = 'white';
                }
             },
             index: function(inputElement) {
                if (inputElement.value < 14000 || inputElement.value > 21000) {
                    this.markAsInvalid(inputElement, 'index');
                } else {
                    inputElement.style.backgroundColor = 'white';
                }
             },
             naziv: function(inputElement) {
                let regexNaziv = /^[A-Za-z0-9\\/\-"'!?:;,]{3,}[0-9a-z]$/;
               if (!regexNaziv.test(inputElement)) {
                   this.markAsInvalid(inputElement, 'naziv');
               } else {
                   inputElement.style.backgroundColor = 'white';
               }
            },
            password: function(inputElement) {
               let password = inputElement.value;
               let regexMaloSlovo = new RegExp("^(?=.*[a-z])");
               let regexVelikoSlovo = new RegExp("^(?=.*[A-Z])");
               let regexBroj = new RegExp("^(?=.*[0-9])");
               let regexMinOsamZnakova = new RegExp("^(?=.{8,})");
 
               let validDuzina = regexMinOsamZnakova.test(password);
               let validMaloSlovo = regexMaloSlovo.test(password);
               let validVelikoSlovo = regexVelikoSlovo.test(password);
               let validBroj = regexBroj.test(password);
 
               let validTotal = true;
 
               validTotal = validDuzina && (
                   (validVelikoSlovo && (validBroj || validMaloSlovo)) ||
                   (validMaloSlovo && (validBroj || validVelikoSlovo)) ||
                   (validBroj && (validVelikoSlovo || validMaloSlovo))
               );
 
               if (!validTotal) {
                   this.markAsInvalid(inputElement, 'password');
               } else {
                   inputElement.style.backgroundColor = 'white';
               }
 
            },
            url: function(inputElement) {
               const regexUrl = /^(http(s?)|ftp|ssh):\/\/\b(\w+\.?)+(?!^\.)\b((\/\w+)*(?:(?=\?)\?([a-z\d\-]+=[a-z\d\-]+&?)+|(?!\?)\/?)(?<![&]))?$/gmi;
               if (!regexUrl.test(inputElement.value)) {
                   this.markAsInvalid(inputElement, 'url');
               } else {
                   inputElement.style.backgroundColor = 'white';
               }
            }
       }
   }
 
   var markAsInvalid = function(inputElement, tekst) {
       inputElement.style.backgroundColor = 'orangered';
       this.staNijeValidno.push(tekst);
       this.sveValidno = false;
   }
 
   return konstruktor;
}());
 
var validirajFormu = function(idForme, idDivaPoruke, options = {}) {

    const defaultOptions = {
        ime: ['ime'],
        godina: ['godina'],
        index: ['index'],
        repozitorij: ['repozitorij'],
        naziv: ['naziv'],
        password: ['password'],
        url: ['url'],
    };

    var options = options;

    let $forma = document.getElementById(idForme);
    let $divPoruke = document.getElementById(idDivaPoruke);
    
    if (!$forma) {
        console.warn(`Forma sa id-em ${idForme} ne postoji`);
        return -1;
    }
    if (!$divPoruke) {
        console.warn(`Div sa id-em ${idDivaPoruke} ne postoji`);
        return -1;
    }
 
    $forma.querySelector('button[name="submit"]').addEventListener('click', function(e) {
        e.preventDefault();
    
        let validacija = new Validacija($divPoruke);
    
        validacija.staNijeValidno = [];
        validacija.sveValidno = true;
    
        let input;

        for (let prop in defaultOptions) {
            if (defaultOptions.hasOwnProperty(prop)) { // klasicna provjera
                let key = defaultOptions[prop];
                if (options.hasOwnProperty(prop)) {
                    key = options[prop]; // ako su poslane custom opcije za nesto
                }

                key.forEach(name => {
                    if (prop == 'godina') {
                        input = $forma.querySelector(`select[name="${name}"]`);
                    } else {
                        input = $forma.querySelector(`input[name="${name}"]`);
                    }
                    if (input) {
                        console.log(validacija[prop](input));
                    }
                });
            }
        }
    
        if (!validacija.sveValidno) {
            validacija.$divElementPoruke.style.display = 'block';
            validacija.$divElementPoruke.innerHTML = 'Sljedeća polja nisu validna:' + validacija.staNijeValidno.join(',') + '!';
        } else {
            validacija.$divElementPoruke.style.display = 'none';
            $forma.submit();
        }
   });
 
}