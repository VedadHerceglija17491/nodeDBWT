function promijeniAction(){
    console.log("tu");
    var forma=document.getElementById("fPoveziZadatak");
    var izabranaVjezba=document.getElementsByName("sVjezbe")[1];
    var selektovaniID = izabranaVjezba.options[izabranaVjezba.selectedIndex].value;
    console.log(selektovaniID);
    forma.action = "/vjezba/"+selektovaniID+"/zadatak";
    forma.submit();
}