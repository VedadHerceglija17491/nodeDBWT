function druga() {
    var ajax = new XMLHttpRequest();
    
    var selekt = document.getElementsByName("sZadatak")[0];
 /*   var opcija=document.getElementsByName("sVjezbe")[1];
    var kojaje=opcija.options[opcija.selectedIndex].value;
    console.log(kojaje);*/
    ajax.onreadystatechange = function() {
        if(ajax.readyState == 4 && ajax.status == 200) { 
            var nizZadaci = JSON.parse(ajax.responseText);

            for(var i=0; i<nizZadaci.length; i++) {
                var option = document.createElement("option");
                option.value = option.text = nizZadaci[i].naziv;               
                selekt.add(option);
              
            }
       

        }
        if(ajax.readyState == 4 && ajax.status == 404) {
            document.write = "Greska";
        }
    }
   
    ajax.open('GET', 'http://localhost:8080/popunizadatke', true);
    ajax.send();
}