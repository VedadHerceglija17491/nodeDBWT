/**/
/*var lista;

var BitBucket = (function(){
    var konstruktor = function(key,secret){
       
            return {
                ucitaj:function(nazivRepSpi,nazivRepVje, fnCallback){
                    
                   
                    odgovor =[{"imePrezime":"AmilaLjutovic","index":"17689"},{"imePrezime":"AmraMemagic","index":"17628"},{"imePrezime":"SelmaLekic","index":"17698"},{"imePrezime":"AjdinaMemisevic","index":"17676"}];
                    fnCallback(odgovor);
                    }
        
            }
        }
    return konstruktor;
}());*/
var pomocni=[];
function popuni() {
    var ajax = new XMLHttpRequest();
    var selekt = document.getElementsByName("sGodina")[0];
    
    var nizGodine;
    ajax.onreadystatechange = function() {
        if(ajax.readyState == 4 && ajax.status == 200) { 
             nizGodine = JSON.parse(ajax.responseText);
           

            for(var i=0; i<nizGodine.length; i++) {
                var option = document.createElement("option");
                option.value = nizGodine[i].id; 
                option.text = nizGodine[i].nazivGod;   
                pomocni.push(nizGodine[i]);            
                selekt.add(option);
                
            }
           
           
           
        }
        if(ajax.readyState == 4 && ajax.status == 404) {
            document.write = "Greska";
        }
    }
   

    ajax.open('GET', 'http://localhost:8080/godine', true);
    ajax.send();
   
}






var lista;
var BitBucket = (function(){
    
    var konstruktor = function(key, secret){
       
        var token = new Promise(
            function (resolve, reject) {
               
            var ajax = new XMLHttpRequest();
            ajax.onreadystatechange = function () { 
            if (ajax.readyState == 4 && ajax.status == 200) {
              
                       resolve(JSON.parse(ajax.responseText).access_token);
                       reject("Greska!");
                         
              
            }
                
            
            if ( ajax . readyState == 4 && ajax . status == 404 ) {
                console.log("Greska!");
            }
        }
        

        ajax.open ( "POST", "https://bitbucket.org/site/oauth2/access_token", true ) ;
        ajax.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
        ajax.setRequestHeader("Authorization", 'Basic ' + btoa(key+':'+secret));
        //console.log(key +","+ secret);
        ajax.send("grant_type="+encodeURIComponent("client_credentials"));
    }
        );
        return {
            ucitaj: function(nazivRepSpi, nazivRepVje, fnCallback)
            {
                
                
                token.then(function(mojtoken) {
                var ajax = new XMLHttpRequest();
                ajax.onreadystatechange = function(){
                    if (ajax.readyState == 4 && ajax.status == 200){
                        console.log(mojtoken);
                     
                        
                      
                     
                     
                      var listaStudenata=[];
                      for(var i=0; i<JSON.parse(ajax.responseText).values.length; i++) {
                        var imaIsti=false;
                        console.log("tu sam")
                       if(JSON.parse(ajax.responseText).values[i].name.startsWith(nazivRepSpi) || JSON.parse(ajax.responseText).values[i].name.startsWith(nazivRepVje)) {
                        for(var j=i+1; j<JSON.parse(ajax.responseText).values.length; j++) {
                            if(JSON.parse(ajax.responseText).values[i].owner.display_name==JSON.parse(ajax.responseText).values[j].owner.display_name) {
                                imaIsti=true;
                                
                            }
                        }
                        if(imaIsti==false) {
                            var objekat={imePrezime:JSON.parse(ajax.responseText).values[i].owner.display_name,index:JSON.parse(ajax.responseText).values[i].name.substr(JSON.parse(ajax.responseText).values[i].name.length-5)}
                            listaStudenata.push(objekat);
                        }
                        
                       
                       }
                    }
                    
                    fnCallback(null,listaStudenata);
                     //   console.log(JSON.parse(ajax.responseText).values[0].name.substr(i));
                      //  console.log(JSON.parse(ajax.responseText).values[0].owner.display_name);
             
                    }
                    else if (ajax.readyState == 4)
                    fnCallback("Greska",null);
                }
               
                ajax.open("GET","https://api.bitbucket.org/2.0/repositories?role=member&q=(name~\""+encodeURIComponent(nazivRepSpi)+"\" OR name~\""+encodeURIComponent(nazivRepVje)+"\")");
                ajax.setRequestHeader("Authorization", 'Bearer ' + mojtoken);
                ajax.send();

               
            });
            

            }
        
        
        }

    }
    return konstruktor;
}());

/*function klik() {
    //var key = document.getElementsByName("key");
   // var secret = document.getElementsByName("secret");


    var bbucket = new BitBucket(encodeURIComponent("vJa8G5yFaAhz6gEN35"),encodeURIComponent("wVvYsUJjQThuKqd3sB6ujWArfeHFs3NP"));
    function ispisi(greska,x){if (greska==null)console.log("Lista studenata:\n"+JSON.stringify(x));}
    //sljedeÄ‡i poziv se treba nalaziti u try-catch bloku:
    bbucket.ucitaj("wtv2018","wt18",ispisi);


}*/
function ajax() {
   var ajax = new XMLHttpRequest();
   console.log("klik")
   var selekt=document.getElementsByName("sGodina")[0];
          var selektovani=selekt.options[selekt.selectedIndex].value;
          var posalji={godina:selektovani,studenti:lista}; 
          
    ajax.onreadystatechange = function() {
        if(ajax.readyState == 4 && ajax.status == 200) { 
            var poruka=JSON.parse(ajax.responseText)
           alert(poruka.message)
            

        }
        if(ajax.readyState == 4 && ajax.status == 404) {
            document.write = "Greska";
        }
    }
 

    ajax.open('POST', 'http://localhost:8080/student', true);
   ajax.setRequestHeader('Content-Type','application/json')
    ajax.send(JSON.stringify(posalji));
   
}

function pozovi(){
    

/*var key= document.getElementsByName("key")[0]
var secret= document.getElementsByName("secret")[0]
var bbucket = new BitBucket(key, secret);
function ispisi(x){
    //console.log('Lista studenata:\n'+JSON.stringify(x));
    var dugme=document.getElementById("unesi2").disabled=false;

    lista=x;
}

bbucket.ucitaj('wt2018','wtProjekat18',ispisi);*/

var godina=document.getElementsByName("sGodina")[0];
var selektovani=godina.options[godina.selectedIndex].value;
var odabrani=0;
for(var i=0; i<pomocni.length; i++) {
    if(pomocni[i].id==selektovani) odabrani=i;
}
//console.log(selektovani)


var key= document.getElementsByName("key")[0]
var secret= document.getElementsByName("secret")[0]

var bbucket = new BitBucket(encodeURIComponent(key.value.toString()),encodeURIComponent(secret.value.toString()));
    function ispisi(greska,x){if (greska==null) {var dugme=document.getElementById("unesi2").disabled=false;

    lista=x;} }
    //sljedeÄ‡i poziv se treba nalaziti u try-catch bloku:
    bbucket.ucitaj(pomocni[odabrani].nazivRepSpi,pomocni[odabrani].nazivRepVje,ispisi);
//console.log(lista)

}
