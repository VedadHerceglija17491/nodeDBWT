var BitBucket = (function(){

    var token;
    var refresh_token;
    var greska;


    var konstruktor = function(key, secret){
                
        
        function DajToken(){
            return new Promise(function(resolve,reject){
                    setTimeout(function(){
                        var ajax = new XMLHttpRequest();
            
                        ajax.onreadystatechange = function() {// Anonimna funkcija
                            if (ajax.readyState == 4 && ajax.status == 200) {
                                token = JSON.parse(ajax.responseText).access_token
                                resolve(token)
                            } else {
                                if (ajax.status == 400) {
                                    reject("Token nije validan");
                                }
                            }
            
                        }
                        ajax.open("POST", "https://bitbucket.org/site/oauth2/access_token", true);
                        ajax.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
                        ajax.setRequestHeader("Authorization", 'Basic ' + btoa(key+":"+secret));
                        ajax.send("grant_type="+encodeURIComponent("client_credentials"));
                },2000);
            });
        }
        
        function getAccessToken(){
            var ajax = new XMLHttpRequest();
        
            ajax.onreadystatechange = function() {// Anonimna funkcija
                if (ajax.readyState == 4 && ajax.status == 200) {
                    greska = null;
                    token = JSON.parse(ajax.responseText).access_token
                    refresh_token = JSON.parse(ajax.responseText).refresh_token
                } else {
                    if (ajax.status == 400) {
                        greska = "Token nije validan";
                    }
                }

            }
            ajax.open("POST", "https://bitbucket.org/site/oauth2/access_token", true);
            ajax.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
            ajax.setRequestHeader("Authorization", 'Basic ' + btoa(key+":"+secret));
            ajax.send("grant_type="+encodeURIComponent("client_credentials"));
        }
        
        getAccessToken();
        
        function jeNaPocetku(pocetak, string) {
            var jednak = true;
            if (string.length<pocetak.length) return false;
            for(j=0; j<pocetak.length; j++) {
                if (pocetak[j] != string[j]){
                    jednak = false;
                    break;
                }
              
            }
            return jednak;
        }
        
        return {
            ucitaj:function(nazivRepSpi,nazivRepVje,callback){
               
                var ajax = new XMLHttpRequest();
                ajax.onreadystatechange = function(){
                    if (ajax.readyState == 4 && ajax.status == 200)
                        {
                            var listaStudenata = []
                            var repozitoriji = JSON.parse(ajax.responseText).values;
                            //provjera da li je na pocetku 
                            for(var i=0; i<repozitoriji.length; i++) {                               
                                if (!jeNaPocetku(nazivRepSpi, repozitoriji[i].slug) && !jeNaPocetku(nazivRepVje, repozitoriji[i].slug)) {
                                    repozitoriji.splice(i,1)
                                    i--;
                                }
                            }

                            //dodavanje studenata
                           
                            for(var i=0; i<repozitoriji.length; i++) {
                                var postoji = false;
                                var imeRepa = repozitoriji[i].slug;
                                var indexStud = "";
                                for (var j = imeRepa.length-5;j<imeRepa.length;j++){
                                    indexStud+=imeRepa[j];
                                }
                                //provjeravanje da li postoje studenti sa istim indexom
                                for (var j = 0;j<listaStudenata.length;j++){
                                    if(listaStudenata[j].index == indexStud) {
                                        postoji=true;
                                        break;
                                    }
                                }
                              
                                if(!postoji) {
                                    listaStudenata.push({
                                        imePrezime: repozitoriji[i].owner.username,
                                        index : indexStud
                                    })
                                }
                                    
                                
                            }
                        
                            callback(null, listaStudenata)
            
                        }
                    else if (ajax.readyState == 4)
                        console.log(ajax.status);
                }
                DajToken().then(function(token){
                    ajax.open("GET","https://api.bitbucket.org/2.0/repositories?role=member&slug=+%3E+%22"+nazivRepSpi+"%22+OR+slug=+%3E+%22"+nazivRepVje+"%22");
                ajax.setRequestHeader("Authorization", 'Bearer ' + token);
                ajax.send();
                }).catch(function(err){
                    callback(err, null)
                })
            
            },
            
           
            SpajanjeGodineIStudenta:function(studentJSON, callback) {
                var ajax = new XMLHttpRequest();
                ajax.onreadystatechange = function() {// Anonimna funkcija
               
                
                    if (ajax.readyState == 4 && ajax.status == 200) {

                        callback(ajax.response)
                    }
                      
                }
        
                ajax.open("POST", "http://localhost:8080/student", true);
                ajax.setRequestHeader("Content-Type", "application/json");
                ajax.send(JSON.stringify(studentJSON));
            }
        }
    }
    return konstruktor;
}());
