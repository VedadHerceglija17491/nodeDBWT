document.addEventListener("DOMContentLoaded", function(){
    // Handler when the DOM is fully loaded

    var mojDiv = document.getElementById("mojDiv");

    let tabela = null;

    var kreiranjeTabele = function() {
        let brojZadataka = document.querySelector('#brojZadataka').value;
        if (brojZadataka < 0) {
            alert('Broj zadataka mora biti pozitivan');
        }
        else if (tabela === null) {
            tabela = new CommitTabela(mojDiv, brojZadataka);
            document.querySelector('#tabelaFunctionsOther').style.display = 'block';
        } else {
            alert('Vec ste dodali tabelu');
        }
        
    };

    var dodavanjeCommita = function() {
        let brojZadatka = document.querySelector('#brojZadatka').value;
        const url = document.querySelector('#url').value;
        if (tabela !== null) {
            if (tabela.dodajCommit(brojZadatka - 1, url) === -1) {
                alert('Nepostojeci zadatak');
            }
        } else {
            alert('Niste dodali tabelu');
        }
    };

    var editovanjeCommita = function() {
        const brojZadatka = document.querySelector('#brojZadatkaZaEdit').value;
        const noviUrl = document.querySelector('#noviUrl').value;
        const rbCommita = document.querySelector('#redniBrojCommitaZaEdit').value;
        if (tabela !== null) {
            if (tabela.editujCommit(brojZadatka - 1, rbCommita - 1, noviUrl) === -1) {
                alert('Nepostojeci zadatak ili commit');
            } else {
                alert('Uspjesno izmjenjen commit');
            }
        } else {
            alert('Niste dodali tabelu');
        }
    };

    var brisanjeCommita = function() {
        const brojZadatka = document.querySelector('#brojZadatkaZaBrisanje').value;
        const rbCommita = document.querySelector('#brojCommitaZaBrisanje').value;
        if (tabela !== null) {
            if (tabela.obrisiCommit(brojZadatka - 1, rbCommita - 1) === -1) {
                alert('Nepostojeci zadatak');
            }
        } else {
            alert('Niste dodali tabelu');
        }
    };

    document.querySelector('#btnDodajTabelu').addEventListener('click', kreiranjeTabele, false);

    document.querySelector('#btnDodajCommit').addEventListener('click', dodavanjeCommita);

    document.querySelector('#btnEditCommit').addEventListener('click', editovanjeCommita);

    document.querySelector('#btnObrisiCommit').addEventListener('click', brisanjeCommita);

    // Podrzavamo 'ENTER'

    document.getElementById('brojZadataka').addEventListener("keyup", function(event) {
        // Cancel the default action, if needed
        // event.preventDefault();
        // Number 13 is the "Enter" key on the keyboard
        if (event.keyCode === 13) {
            // document.getElementById('btnDodajTabelu').click();     
            kreiranjeTabele();      
        }
    });

    // Execute a function when the user releases a key on the keyboard
    document.getElementById('url').addEventListener("keyup", function(event) {
        // Cancel the default action, if needed
        event.preventDefault();
        // Number 13 is the "Enter" key on the keyboard
        if (event.keyCode === 13) {
            dodavanjeCommita();            
        }
    });

    document.getElementById('noviUrl').addEventListener("keyup", function(event) {
        // Cancel the default action, if needed
        event.preventDefault();
        // Number 13 is the "Enter" key on the keyboard
        if (event.keyCode === 13) {
            editovanjeCommita();            
        }
    });

    document.getElementById('brojCommitaZaBrisanje').addEventListener("keyup", function(event) {
        // Cancel the default action, if needed
        event.preventDefault();
        // Number 13 is the "Enter" key on the keyboard
        if (event.keyCode === 13) {
            brisanjeCommita();            
        }
    });

    // ------------------------------------------------------------

    

    // var tabela = new CommitTabela(mojDiv, 4);

    // tabela.dodajCommit(0, "test");
    // tabela.dodajCommit(1, "test");
    // tabela.dodajCommit(2, "test");
    // tabela.dodajCommit(0, "test");
    // tabela.dodajCommit(1, "test");
    // tabela.dodajCommit(1, "test");
    // tabela.dodajCommit(3, "test");
    // tabela.dodajCommit(0, "test");
    // tabela.dodajCommit(0, "test");
    // tabela.dodajCommit(3, "test");
    // tabela.dodajCommit(3, "test");
    // tabela.dodajCommit(3, "test");
    // tabela.dodajCommit(3, "test");
    // tabela.dodajCommit(1, "test");
    // tabela.dodajCommit(2, "test");
    // tabela.dodajCommit(0, "test");

    // console.log(tabela.obrisiCommit(1, 0));
    // console.log(tabela.obrisiCommit(1, 0));
    // console.log(tabela.obrisiCommit(2, 0));
    // console.log(tabela.obrisiCommit(0, 1));
    // console.log(tabela.obrisiCommit(0, 0));
    // console.log(tabela.obrisiCommit(1, 0));

    // console.log(tabela.editujCommit(1,1, 'noviurl'));
    
    // tabela.dodajCommit(0, "test");
    // tabela.dodajCommit(0, "test");
    // tabela.dodajCommit(3, "test");
    // tabela.dodajCommit(3, "test");
});