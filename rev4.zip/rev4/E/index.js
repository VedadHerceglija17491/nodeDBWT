const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');
const multer = require('multer');
const app = express();
var json2csv = require('json2csv');
const Sequelize = require('sequelize');
const db = require('./db.js');
app.use(bodyParser.json());

app.use(bodyParser.urlencoded({ extended: true }));
db.sequelize.sync();

app.get('/s', function(req, res) {
    res.render('greska');
});

//http://localhost:8080/zadatak?naziv=Zadatak1
app.get('/zadatak', function(req, res) {
   
    var naziv1 = req.query.naziv
  /*  var file = __dirname + '/zadaci/' + naziv+'.pdf';

   if(fs.existsSync(file)) res.sendFile(file);
   else res.send("Ne postoji zadatak");*/
   db.zadatak.findOne({where:{naziv:naziv1}}).then(function(odg)
    {
        if(odg==null) res.send("Ne postoji zadatak");
        else {
            var file = __dirname + '/zadaci/' + odg["naziv"]+'.pdf';
        res.sendFile(file);
    }
    });
    
});


app.post('/addGodina', function(req, res) {
    
    var tijelo = req.body
    var csv = json2csv.parse(tijelo).replace(/"/g, '');
    var csv2=csv.substr(34);

    var podaci=csv2.split(",");
    var godina2=csv2.split(",")[0];
    db.godina.findOne({where:{nazivGod:godina2}}).then(function(odg)
    {
       if(odg==null){
           db.godina.create({nazivGod: podaci[0], nazivRepVje:podaci[1], nazivRepSpi: podaci[2] }).then( function(odg1) {
               res.end();
            });

        }
        else{
            res.redirect("/greska.html");
        }
       // res.redirect('back');
    });
/* 
    var path='./godine.csv';
    if(fs.existsSync(path)){
        csv2='\r\n'+csv2;
       
        fs. readFile('godine.csv', function(err, contents) {
            var provjera=false;
            var redovi=contents.toString().split("\n");
            var nizZaJson=[];
            for(var i=0; i<redovi.length; i++) {
                var kolona=redovi[i].split(",");
                var objekat={nazivGod:kolona[0], nazivRepVje:kolona[1], nazivRepSp:kolona[2]};
                nizZaJson.push(objekat);
            }
            for(var i=0; i<redovi.length; i++) {
                if(nizZaJson[i].nazivGod==godina) provjera=true;
            }
            if(provjera==false){
                fs.appendFile('godine.csv', csv2, function (err) {
                    if (err) throw err;
                   
                    res.redirect('/addGodina.html');
                 
                });  
               
                //spirala4

                
            }
            else res.redirect('/greska.html'); 
        });


    }
    else{
        fs.appendFile('godine.csv', csv2, function (err) {
        if (err) throw err;
       
        res.redirect('/addGodina.html');
    });
}*/

});
app.post('/addZadatak', function(req,res){
    
    
    var storage = multer.diskStorage({
        destination: (req, file, cb) => {
          cb(null, './zadaci')
        },
        filename: (req, file, cb) => {
            var n=req.body;
            naziv=req.body.naziv;
          //  console.log(naziv);
          cb(null,n.naziv +'.pdf' )
        }

    });

    
  var uploadPost = multer({ fileFilter: function (req, file, cb) { 
      
    var path='./zadaci/'+req.body.naziv+'.pdf';

    if (file.mimetype !== 'application/pdf') {
            return cb(new Error('Nije pdf'))
     }
     
    
     if(fs.existsSync(path)){
        return cb(new Error('Postoji file sa ovim nazivom'))
     }

    cb(null, true)
  },
  storage: storage} ).single('postavka');
    uploadPost(req, res, function(err) {

        if(err) {
            return res.redirect("/greska.html");
        }
        
        var ime=req.body.naziv;
        var zadaci={"naziv": ime,
            "postavka": "http://localhost:8080/zadatak?naziv="+ime};
            var konacno = JSON.stringify(zadaci);
            db.zadatak.create({naziv: ime, postavka: "http://localhost:8080/zadatak?naziv="+ime }).then( function(odg) {
                console.log("upisno");
            })
   fs.writeFile("./zadaci/"+ime+".json", konacno,function (err) {
    if (err){ 
        throw err;}
   });



        res.end();
    });
    //console.log(file.filename);
    //res.redirect('/addGodina.html');
  //  res.redirect("/addZadatak.html");
});

app.get('/godine',function(req,res){
  /*  var path='./godine.csv';
    if(fs.existsSync(path)){
    fs. readFile('godine.csv', function(err, contents) {
        
        var redovi=contents.toString().split("\n");
        var nizZaJson=[];
        for(var i=0; i<redovi.length; i++) {
            var kolona=redovi[i].split(",");
            var objekat={nazivGod:kolona[0], nazivRepVje:kolona[1], nazivRepSp:kolona[2]};
            nizZaJson.push(objekat);
        }
        res.writeHead(200, {'Content-Type': '/application/json'});
        res.end(JSON.stringify(nizZaJson)); 
    });
    }*/
    db.godina.findAll().then(function(odgovor)
    {
         
        if(odgovor==null){
            var nizZaJson=[];
            res.writeHead(200, {'Content-Type': '/application/json'});
        res.end(JSON.stringify(nizZaJson)); 
        }
        else{
        var nizZaJson=[];
        for(var i=0; i<odgovor.length; i++) {
            var objekat={id:odgovor[i]["id"],nazivGod:odgovor[i]["nazivGod"], nazivRepVje:odgovor[i]["nazivRepVje"], nazivRepSpi:odgovor[i]["nazivRepSpi"]};
            nizZaJson.push(objekat);
        }
        res.writeHead(200, {'Content-Type': '/application/json'});
        res.end(JSON.stringify(nizZaJson)); 
    }
    });
});
app.get('/zadaci',function(req,res){
    
    /*var request = req.get(fileUrl, function (res) {
        var contentType = res.headers['content-type'];
        res.send(contentType.indexOf('application/xml').toString());
      });*/
    /*if(req.accepts("html") ){
        res.send("nije");
    }*/
    var acceptType = req.headers['accept'];

     
    if(req.accepts('json')){

     /*   fs. readFile('zadaci.txt', function(err, contents) {
            var nizZaJson=[];
            var redovi=contents.toString().split("\n");
            
            for(var i=0; i<redovi.length; i++) {
                var kolona=redovi[i].split(" ");
                var objekat={naziv:kolona[0], postavka:kolona[1]};
                nizZaJson.push(objekat);
            }
            res.writeHead(200, {'Content-Type': 'application/json'});
            res.end(JSON.stringify(nizZaJson));  
        });*/
        db.zadatak.findAll().then(function(odgovor)
        {
             
            if(odgovor==null){
                var nizZaJson=[];
                res.writeHead(200, {'Content-Type': '/application/json'});
            res.end(JSON.stringify(nizZaJson)); 
            }
            else{
            var nizZaJson=[];
            for(var i=0; i<odgovor.length; i++) {
                var objekat={naziv:odgovor[i]["naziv"], postavka:odgovor[i]["postavka"]};
                nizZaJson.push(objekat);
            }
            res.writeHead(200, {'Content-Type': '/application/json'});
            res.end(JSON.stringify(nizZaJson)); 
        }
        });


    }

    else if(!req.accepts('json') && (req.accepts('application/xml')|| req.accepts('text/xml')))
    {
     //   json=nizZaJson[0];
       // const xml = toXml(json);
       // res.writeHead(200, {'Content-Type': 'application/xml'});
      //  res.send(nizZaJson.length.toString());
      
      function OBJtoXML(obj) {
    var xml = '';
        for (var prop in obj) {
          xml += obj[prop] instanceof Array ? '' : "<" + prop + ">";
          if (obj[prop] instanceof Array) {
            for (var array in obj[prop]) {
              xml += "<" + prop + ">";
              xml += OBJtoXML(new Object(obj[prop][array]));
              xml += "</" + prop + ">";
            }
          } else if (typeof obj[prop] == "object") {
            xml += OBJtoXML(new Object(obj[prop]));
          } else {
            xml += obj[prop];
          }
          xml += obj[prop] instanceof Array ? '' : "</" + prop + ">";
        }
        var xml = xml.replace(/<\/?[0-9]{1,}>/g, '');
        return xml;
      }
     
     /*fs. readFile('zadaci.txt', function(err, contents) {
        
        var redovi=contents.toString().replace(/\r\n/g,'\n').split("\n");
        var nizZaJson=[];
        for(var i=0; i<redovi.length; i++) {
            var kolona=redovi[i].split(" ");
            var objekat={naziv:kolona[0], postavka:kolona[1]};
            nizZaJson.push(objekat);
        }

        var niz=JSON.stringify(nizZaJson);
       var uvod= '<?xml version="1.0" encoding="UTF-8"?>';
      var InputJSON = '{"zadaci":{"zadatak":'+niz+ '}}';
      var InputJSON = JSON.parse(InputJSON);
      var xml=OBJtoXML(InputJSON);
    if(req.accepts('application/xml'))  res.writeHead(200, {'Content-Type': 'application/xml'});
    else res.writeHead(200, {'Content-Type': 'text/xml'});
      res.end(uvod+xml); 
    });*/
    db.zadatak.findAll().then(function(odgovor)
    {
       /* if(odgovor==null){
            var nizZaJson=[];
            if(req.accepts('application/xml'))  res.writeHead(200, {'Content-Type': 'application/xml'});
    else res.writeHead(200, {'Content-Type': 'text/xml'});
    res.end(nizZaJson);
        }*/
       // else{
        var nizZaJson=[];
            for(var i=0; i<odgovor.length; i++) {
                var objekat={naziv:odgovor[i]["naziv"], postavka:odgovor[i]["postavka"]};
                nizZaJson.push(objekat);
            }
    var niz=JSON.stringify(nizZaJson);
    var uvod= '<?xml version="1.0" encoding="UTF-8"?>';
   var InputJSON = '{"zadaci":{"zadatak":'+niz+ '}}';
   var InputJSON = JSON.parse(InputJSON);
   var xml=OBJtoXML(InputJSON);
 if(req.accepts('application/xml')) res.writeHead(200, {'Content-Type': 'application/xml'});
 else res.writeHead(200, {'Content-Type': 'text/xml'});
   res.end(uvod+xml);
       // }
        }); 
    
      }
    else if(!req.accepts('json') && !req.accepts('xml') && req.accepts('csv')) {
        
        /*fs. readFile('zadaci.txt', function(err, contents) {
            var nizZaJson=[];
            var redovi=contents.toString().replace(/\r\n/g,'\n').split("\n");
            
            for(var i=0; i<redovi.length; i++) {
                var kolona=redovi[i].split(" ");
                var objekat={naziv:kolona[0], postavka:kolona[1]};
                nizZaJson.push(objekat);
            }
           
           // var jason=JSON.stringify(nizZaJson);
           
            var csv = json2csv.parse(nizZaJson).replace(/"/g, '');
            csv=csv.substr(16);
           res.writeHead(200, {'Content-Type': 'text/csv'});
            res.end(csv); 
        });*/
        
        db.zadatak.findAll().then(function(odgovor)
        {
            var nizZaJson=[];
            for(var i=0; i<odgovor.length; i++) {
                var objekat={naziv:odgovor[i]["naziv"], postavka:odgovor[i]["postavka"]};
                nizZaJson.push(objekat);
            }
            if(nizZaJson.length!=0){
            var csv = json2csv.parse(nizZaJson).replace(/"/g, '');
        
            csv=csv.substr(16);
            
            res.writeHead(200, {'Content-Type': 'text/csv'});
            res.end(csv); 
            }
            else{
                res.writeHead(200, {'Content-Type': 'text/csv'});
            res.end(csv); 
            }

        });

    }
});
/*app.get('/addVjezba.html',function(req,res){
    //var path='./public/addVjezba.html';
    var select = document.getElementByTagName('sGodine');
    db.godina.findAll().then(function(odgovor)
    {
    for (var i = 0; i<odgovor.length; i++){
    var opt = document.createElement('option');
    opt.value =i;
    opt.innerHTML = odgovor[i]["nazivGod"];
    select.appendChild(opt);
        }
    });
    res.writeHead(200, {'Content-Type': 'application/html'});
            res.end(path); 
    
});*/
/*app.post('/addVjezba',function(req, res) {
        var godinaId = req.body.sGodine;
        var vjezbaId = req.body.sVjezbe;
    console.log(req.body.sGodine);
      godina.findByPk(godinaId).then(g => { 
            g.getVjezbe().then(vjezbe => {
                if (!vjezbe.find(x => x.dataValues.id == vjezbaId)) {
                    g.addVjezbe(vjezbaId).then(() => {
                        res.sendFile(path.join(__dirname, '/public/addVjezba.html'));
                    });
                } else {
                    res.sendFile(path.join(__dirname, '/public/addVjezba.html'));
                }
            });
        });
    });*/
 

app.post('/addVjezba',function(req,res){
    var naz=req.body.naziv;
   
   // godinaVjezba=godina.belongsToMany(vjezba,{as:'vjezbe',through:'godina_vjezba',foreignKey:'idgodine'});
    //vjezba.belongsToMany(godina,{as:'godine', through:'godina_vjezba',foreignKey:'idvjezba'});   
    if(req.body.naziv!=null){
        console.log(req.body.naziv);
        var spi=false;
        if(req.body.spirala=='on') spi=true;
    var godinaNaziv = req.body.sGodine;
    var vjezbaNaziv = req.body.naziv;
    console.log(req.body);
    db.vjezba.find({where:{naziv: vjezbaNaziv}}).then(function(prviOdg){
        console.log(prviOdg);
        if(prviOdg==null){
   db.vjezba.create({naziv: vjezbaNaziv, spirala:spi}).then( function(odgg) {
    console.log("hoce da kreira");
        if(odgg!=null)
       { 
           
           db.godina.findOne({where:{nazivGod:godinaNaziv}}).then(function(odg){
               
             odg.getVjezbe().then(function(odg2){
               // db.vjezba.findOne({where:{naziv:vjezbaNaziv}}).then(function(odg3){
                    console.log(odgg["id"]);
                    if (!odg2.find(x => x.dataValues.id == odgg["id"])) {
                        odg.addVjezbe(odgg["id"]).then(() => {
                          //  res.redirect('back');
                          console.log("nesto2");
                        });
                    } else {
                        console.log("nesto");
                    }
               // });
           });
    });
    }
}).catch(function(err) {
    // print the error details
    res.end();
});
 }

})

}
else{
   var godinaNaziv = req.body.sGodine;
    db.vjezba.findOne({where:{naziv:req.body.sVjezbe}}).then( function(odgg) {
    db.godina.findOne({where:{nazivGod:godinaNaziv}}).then(function(odg){
           odg.getVjezbe().then(function(odg2){
               // db.vjezba.findOne({where:{naziv:vjezbaNaziv}}).then(function(odg3){
                    console.log(odgg["id"]);
                    if (!odg2.find(x => x.dataValues.id == odgg["id"])) {
                        odg.addVjezbe(odgg["id"]).then(() => {
                          //  res.redirect('back');
                          console.log("nesto2");
                        });
                    } 
                    else {
                        console.log("nesto");
                    }
               // });
           });
         });
    });
}
res.redirect('/addVjezba.html');
});

app.get('/vjezbe',function(req,res){
      db.vjezba.findAll().then(function(odgovor)
      {
           
          if(odgovor==null){
              var nizZaJson=[];
              res.writeHead(200, {'Content-Type': '/application/json'});
          res.end(JSON.stringify(nizZaJson)); 
          }
          else{
          var nizZaJson=[];
          for(var i=0; i<odgovor.length; i++) {
              var objekat={id:odgovor[i]["id"],naziv:odgovor[i]["naziv"]};
              nizZaJson.push(objekat);
          }
          res.writeHead(200, {'Content-Type': '/application/json'});
          res.end(JSON.stringify(nizZaJson)); 
      }
      });
  });

//'/popunjavanjeZadataka/:id
  app.get('/popunjavanjeZadataka/:id',function(req,res){
      
    var idMoj=req.params.id;
    //console.log(idMoj);
    var nizZaJson=[];
        db.zadatak.findAll().then(function(odgovor)
        {
            //odgovor - svi zadaci iz tabele
            db.vjezba.findOne({where:{id:idMoj}}).then(function(odgovor1){
            //odgovor1 - vjezba sa primljenim id-em
            
            odgovor1.getZadaci().then(function(odgovor2){
                //odgovor2 - svi zadaci povezani sa godinom
            for(var i=0; i<odgovor.length;i++){
                if (!odgovor2.find(x => x.dataValues.id == odgovor[i]["id"])) {
                    nizZaJson.push({id:odgovor[i]["id"],naziv:odgovor[i]["naziv"]});
                }                 
            }
            res.writeHead(200, {'Content-Type': '/application/json'});
            res.end(JSON.stringify(nizZaJson)); 
                });
            });
        });
});

  app.post('/vjezba/:idVjezbe/zadatak',function(req,res){

    console.log(req.body.studenti);
    db.vjezba.findOne({where:{id:req.body.sVjezbe}}).then(function(odg){
        odg.addZadaci(req.body.sZadatak);

    });

    res.redirect("/addVjezba.html");

  });
  
 

app.use(express.static('public'));
app.listen(8080);