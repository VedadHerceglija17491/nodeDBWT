//var lista;
var BitBucket = (function(){
    
    var konstruktor = function(key, secret){
        
        var token = new Promise(
            function (resolve, reject) {
            var ajax = new XMLHttpRequest();
            ajax.onreadystatechange = function () { // Anonimna funkcija
            if (ajax.readyState == 4 && ajax.status == 200) {
              
                       resolve(JSON.parse(ajax.responseText).access_token);
                       
                        
                       reject("Greska"); // reject
                         
              
            }
                
            
            if ( ajax . readyState == 4 && ajax . status == 404 ) {
                console.log("Greska");
            }
        }
        

        ajax.open ( "POST", "https://bitbucket.org/site/oauth2/access_token", true ) ;
        ajax.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
        ajax.setRequestHeader("Authorization", 'Basic ' + btoa(key+':'+secret));
        console.log(key +","+ secret);
        ajax.send("grant_type="+encodeURIComponent("client_credentials"));
    }
        );
        return {
            ucitaj: function(nazivRepSpi, nazivRepVje, fnCallback)
            {
                
               
                token.then(function(mojtoken) {
                var ajax = new XMLHttpRequest();
                ajax.onreadystatechange = function(){
                    if (ajax.readyState == 4 && ajax.status == 200){
                        console.log(mojtoken);
                      
                        
                        var nizZaJson=[];
                      
                        for(var i=0; i<JSON.parse(ajax.responseText).values.length;i++){
                               if(JSON.parse(ajax.responseText).values[i].name.startsWith(nazivRepSpi) ||JSON.parse(ajax.responseText).values[i].name.startsWith(nazivRepVje) )
                          { 
                               var provjera=false;
                               var index= JSON.parse(ajax.responseText).values[i].name.substr(JSON.parse(ajax.responseText).values[i].name.length-5);
                               var imePrezime=JSON.parse(ajax.responseText).values[i].owner.display_name;
                                console.log(imePrezime)
                               for(var j=0; j<nizZaJson.length;j++){
                                    if(nizZaJson[j].imePrezime==imePrezime) provjera=true;
                               }

                               if(provjera==false)
                               {
                                   nizZaJson.push({imePrezime:imePrezime, index:index});
                               }
                            }
                            }
                          
                    
                            console.log(JSON.stringify(nizZaJson))
                            fnCallback(null,nizZaJson);
                    }
                    else if (ajax.readyState == 4)
                    fnCallback("Neispravan token",null);
                }
               
                ajax.open("GET","https://api.bitbucket.org/2.0/repositories?role=member&q=(name~\""+encodeURIComponent(nazivRepSpi)+"\" OR name~\""+encodeURIComponent(nazivRepVje)+"\")");
                ajax.setRequestHeader("Authorization", 'Bearer ' + mojtoken);
                ajax.send();

            });
            

            }
        
        
        }

    }
    return konstruktor;
}());