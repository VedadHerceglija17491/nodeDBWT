var VjezbeAjax = (function(){
    var konstruktor = function(godineCallback, vjezbeCallback ,zadaciCallback, divGod,divVje, divGod1, divVje1, divZad){
        
        return {
            dohvatiVjezbe:function(){
                var ajax = new XMLHttpRequest();
                ajax.onreadystatechange = function() {// Anonimna funkcija
                    var string ="";
                   
                    
                    if (ajax.readyState == 4 && ajax.status == 200) {
                        if(ajax.response.length==0) return;
                        var jsonList = JSON.parse(ajax.response)
                        string+= "<select name='sVjezbe' >";

                       for(var i=0; i<jsonList.length; i++) 
                           string+="<option value="+i+">"+jsonList[i].naziv+"</option>";
        
                        divVje.innerHTML=string;
                        divVje1.innerHTML=string;
                        vjezbeCallback(jsonList)
                    }
                      
                }
        
                ajax.open("GET", "http://localhost:8080/vjezbe", true);
                ajax.setRequestHeader("Content-Type", "application/json");
                ajax.send();
            },

            dohvatiGodine:function(){
                var ajax = new XMLHttpRequest();
                ajax.onreadystatechange = function() {// Anonimna funkcija
                    var string ="";
                   
                    
                    if (ajax.readyState == 4 && ajax.status == 200) {
                        if(ajax.response.length==0) return;
                        var jsonList = JSON.parse(ajax.response)
                        string+= "<select name='sGodine'>";

                       for(var i=0; i<jsonList.length; i++) 
                           string+="<option value="+i+">"+jsonList[i].naziv+"</option>";
        
                        divGod.innerHTML=string;
                        divGod1.innerHTML=string;
                        godineCallback(jsonList)
                    }
                      
                }
        
                ajax.open("GET", "http://localhost:8080/godine", true);
                ajax.setRequestHeader("Content-Type", "application/json");
                ajax.send();
            },
            dohvatiZadatke:function(idVjezbe){
                var ajax = new XMLHttpRequest();
                ajax.onreadystatechange = function() {// Anonimna funkcija
                    var string ="";
                   
                    if (ajax.readyState == 4 && ajax.status == 200) {
                        if(ajax.response.length==0) return;
                        var jsonList = JSON.parse(ajax.response)
                        string+= "<select id='sZadatak'>";

                       for(var i=0; i<jsonList.length; i++) 
                           string+="<option value="+i+">"+jsonList[i].naziv+"</option>";
                            
                        divZad.innerHTML=string;
                        zadaciCallback(jsonList)
                    }
                      
                }

               
                ajax.open("GET", "http://localhost:8080/dohvatiZadatke/"+idVjezbe, true);
                ajax.setRequestHeader("Content-Type", "application/json");
                ajax.send();
            },


            spojiGodinuIVjezbu:function(godina, vjezba, refresh){
                var ajax = new XMLHttpRequest();
                ajax.onreadystatechange = function() {// Anonimna funkcija
                    refresh();
                }
                var json = {
                    nazivGod:godina,
                    nazivVje:vjezba
                    };
        
                
                ajax.open("POST", "http://localhost:8080/addVjezba", true);
                ajax.setRequestHeader("Content-Type", "application/json");
                ajax.send(JSON.stringify(json));
            },
            napraviNovuVjezbu:function(godina, naziv, checked, refresh) {
                var ajax = new XMLHttpRequest();
                ajax.onreadystatechange = function() {// Anonimna funkcija
                    refresh();
                }
                var json = {
                    nazivGod:godina,
                    nazivVje:naziv,
                    oznacen:checked
                    };
        
                
                ajax.open("POST", "http://localhost:8080/addVjezba", true);
                ajax.setRequestHeader("Content-Type", "application/json");
                ajax.send(JSON.stringify(json));
            },
            SpojiVjezbuIZadatak:function(idVjezbe, zadatak, refresh) {
                var ajax = new XMLHttpRequest();
                ajax.onreadystatechange = function() {// Anonimna funkcija
                   refresh();
                }
                var json = {
                    nazivZad:zadatak
                    };

                ajax.open("POST", "http://localhost:8080/vjezba/"+idVjezbe+"/zadatak", true);
                ajax.setRequestHeader("Content-Type", "application/json");
                ajax.send(JSON.stringify(json));
            }
           
        }
    }
    return konstruktor;
}());
