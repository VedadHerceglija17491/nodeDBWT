var GodineAjax = (function(){
    var konstruktor = function(divSadrzaj){
        var ajax = new XMLHttpRequest();
        ajax.onreadystatechange = function() {// Anonimna funkcija
            var string ="";
           
            
            if (ajax.readyState == 4 && ajax.status == 200) {
                if(ajax.response.length==0) return;
                var jsonList = JSON.parse(ajax.response)
               for(var i=0; i<jsonList.length; i++) {
                    string += "<div class='godina' ><br><p id='p2'>"+jsonList[i].naziv+"</p><br><p><b>"
                    string+= "Repozitorij vjezbe: </b>"+jsonList[i].nazivRepVje +" <br><b>"
                    string+= "Repozitorij spirale: </b>"+ jsonList[i].nazivRepSpi +" <br></p></div>"
                }

                divSadrzaj.innerHTML=string;
            }
              
        }

        ajax.open("GET", "http://localhost:8080/godine", true);
        ajax.setRequestHeader("Content-Type", "application/json");
        ajax.send();
        return {
            osvjezi:function(){
                var ajax = new XMLHttpRequest();
                ajax.onreadystatechange = function() {// Anonimna funkcija
                    var string ="";
                    if(ajax.response.length==0) return;
                    var jsonList = JSON.parse(ajax.response)
                    
                    if (ajax.readyState == 4 && ajax.status == 200) {
                    if(ajax.response.length==0) return;
                       for(var i=0; i<jsonList.length; i++) {
                            string += "<div class='godina' ><br><p id='p2'>"+jsonList[i].naziv+"</p><br><p><b>"
                            string+= "Repozitorij vjezbe: </b>"+jsonList[i].nazivRepVje +" <br><b>"
                            string+= "Repozitorij spirale: </b>"+ jsonList[i].nazivRepSpi +" <br></p></div>"
                        }
        
                        divSadrzaj.innerHTML=string;
                    }
                      
                }
        
               
                ajax.open("GET", "http://localhost:8080/godine", true);
                ajax.setRequestHeader("Content-Type", "application/json");
                ajax.send();
             },
             dohvatiGodine:function(godineCallback){
                var ajax = new XMLHttpRequest();
                ajax.onreadystatechange = function() {// Anonimna funkcija
                    var string ="";
                   
                    
                    if (ajax.readyState == 4 && ajax.status == 200) {
                        if(ajax.response.length==0) return;
                        var jsonList = JSON.parse(ajax.response)
                        string+= "<select id='sGodine'>";

                       for(var i=0; i<jsonList.length; i++) 
                           string+="<option value="+i+">"+jsonList[i].naziv+"</option>";
        
                        divSadrzaj.innerHTML=string;
                        godineCallback(jsonList)
                    }
                      
                }
        
                ajax.open("GET", "http://localhost:8080/godine", true);
                ajax.setRequestHeader("Content-Type", "application/json");
                ajax.send();
            }
        }

    }
    return konstruktor;
}());
