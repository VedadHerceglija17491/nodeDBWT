
var brojac=0;
var CommitTabela=(function(){

	var konstruktor=function(divElement,brojZadataka){
      
     
        var tabela = document.createElement("table");
        var tblBody = document.createElement("tbody");
       
       
        var row = tabela.insertRow(0);
       
        
        var cell1 = row.insertCell(0);
        var cell2 = row.insertCell(1);
        
       
        cell1.innerHTML = "Naziv Zadatka";
        cell2.innerHTML = "Commiti";
       
        for(var i=1; i<4; i++) {
            var row=tabela.insertRow();
            var cell1 = row.insertCell();
            var cell2 = row.insertCell();
            
            cell1.innerHTML = "Zadatak"+ i;
           
        }
        tabela.appendChild(tblBody);
      
        divElement.appendChild(tabela);
      
        tabela.setAttribute("border", "2");
        tabela.style.backgroundColor="#add8e6";
        tabela.width="30%";

        var brojac=new Array(3);
        var uslo=new Array(3);  
        var obrisi=new Array(3); 
            for(var i=0; i<brojac.length; i++) {
                brojac[i]=0;
                uslo[i]=0;
                obrisi[i]=0;
            }
  
	return{
        
		dodajCommit:function(rbZadatka,url){
        
            var brZadatka=rbZadatka;
           
           
          
            for(var i=0; i<tabela.rows.length; i++)
            {
              
                var max=tabela.rows[0].cells.length;
                for(var j=0; j<tabela.rows.length; j++) {
                   if(tabela.rows[j].cells.length>max) max=tabela.rows[j].cells.length; 
                } 


            if(i==brZadatka){
                var brojDodanogCommita=tabela.rows[i].cells.length;
                            
                           if(brojDodanogCommita>2) {
                            tabela.rows[i].insertCell(brojDodanogCommita-1);
                            brojac[i]+=1;
                            var a = document.createElement("a");
                            a.innerHTML=brojac[i];
                            a.href=url;
                            tabela.rows[i].cells[brojDodanogCommita-1].appendChild(a);
                            
                            //console.log("aa");
                            }


                          
                            
                            
                            else {
                                tabela.rows[i].insertCell(brojDodanogCommita-1);
                                brojac[i]+=1;
                                
                                var a = document.createElement("a");
                                a.innerHTML=(brojDodanogCommita-1);
                                a.href=url;
                                tabela.rows[i].cells[brojDodanogCommita-1].appendChild(a); 
                             //  
                                console.log(max); 
                            }  
                       }
                    
              //  }
                    
                    else {
                        
                        tabela.rows[i].cells[tabela.rows[i].cells.length-1].colSpan+=1;
                       
                    }
                  
                   
            }
           
           
			},
			editujCommit:function(rbZadatka,rbCommita,url){
        var broj=Number(tabela.rows[rbZadatka].cells[rbCommita].getElementsByTagName("a")[0].innerHTML);
        var brZadatka=rbZadatka;
            for(var i=0; i<tabela.rows.length; i++) {

                if(i==brZadatka) {
                    
                    tabela.rows[i].cells[rbCommita].innerHTML='<a href="'+url+'">'+(broj).toString()+'</a>';
                }
            }
          
            },
			obrisiCommit:function(rbZadatka,rbCommita){
                var brZadatka=rbZadatka;
                for(var i=0; i<tabela.rows.length; i++) {
    
                    if(i==brZadatka) {
                        tabela.rows[i].deleteCell(rbCommita);
                      
                      
                    }
                }

            }
			}
		}
	return konstruktor;
}());

/*function proba(){
    var mojDiv=document.getElementById('glavni');

   tabela= new CommitTabela(mojDiv,4);
  tabela.dodajCommit(1,"www.etf.ba");
  tabela.dodajCommit(1,"www.etf.ba");
 tabela.dodajCommit(1,"www.etf.ba");
  tabela.dodajCommit(2,"www.etf.ba");
 tabela.dodajCommit(2,"www.etf.ba");
  tabela.obrisiCommit(1,1);
  tabela.dodajCommit(1,"www.etf.ba");
  tabela.dodajCommit(2,"www.etf.ba");
  // tabela.dodajCommit(2,"www.etf.ba");
   tabela.dodajCommit(3,"www.etf.ba");
   
   

   tabela.editujCommit(1,2,"https://www.facebook.com/");
 
  tabela.obrisiCommit(1,1);
   tabela.dodajCommit(1,"www.etf.ba");
  tabela.dodajCommit(1,"www.etf.ba");
  tabela.obrisiCommit(1,1);
  tabela.dodajCommit(1,"www.etf.ba");
  tabela.dodajCommit(1,"www.etf.ba");

  tabela.obrisiCommit(2,1);
  tabela.dodajCommit(2,"www.etf.ba");
  tabela.obrisiCommit(2,2);
  tabela.dodajCommit(2,"www.etf.ba");
   tabela.dodajCommit(2,"www.etf.ba");

 //    return CommitTabela.konstruktor.dodajCommit(1,"www.etf.ba");

}*/

