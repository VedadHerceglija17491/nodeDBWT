function cetvrta() {
    var ajax = new XMLHttpRequest();
    
   
    var selekt1=document.getElementsByName("sZadatak")[1];
    
    /*var i=0;
   while(selekt1.options.length!=0) {
       selekt1.remove(i);
       i++;
      if(selekt1.options!=1) selekt1.options.length--;
       console.log("brisem")
   }*/
 /*  var brisi=selekt1.options.length;
   for(var i=0; i<brisi;i++) {
    selekt1.remove(i);
    console.log("brisem")
   }
   console.log(selekt1.options.length)*/
   selekt1.options.length=0;
   
   
    var id=document.getElementsByName("sVjezbe")[1];
    var uzmiid=id.options[id.selectedIndex].value;
   // console.log(uzmiid);
    ajax.onreadystatechange = function() {
        
        if(ajax.readyState == 4 && ajax.status == 200) { 
         

            var nizZadaci2 = JSON.parse(ajax.responseText);

            for(var i=0; i<nizZadaci2.length; i++) {
                var option1 = document.createElement("option");
                option1.value = option1.text = nizZadaci2[i].naziv;               
                selekt1.add(option1);
                
               
            }

        }
        if(ajax.readyState == 4 && ajax.status == 404) {
            document.write = "Greska";
        }
    }
   
    ajax.open('GET', 'http://localhost:8080/popunizadatke2/'+uzmiid, true);
    ajax.send();
}
function peta() {
    var id=document.getElementsByName("sVjezbe")[1];
    var uzmiid=id.options[id.selectedIndex].value;
    var forma=document.getElementsByName("fPoveziZadatak")[0];
    forma.action="/vjezba/"+uzmiid.toString()+"/zadatak";
}



