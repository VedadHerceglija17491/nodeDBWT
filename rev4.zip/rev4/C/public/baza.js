function dodaj() {
	const db= require('./db.js');
	var select = document.getElementById('sGodine2');
	console.log("tuuuuuuuuuuu")
    db.godina.findAll().then(function(odgovor) {
        for (var i = 0; i<odgovor.length; i++){ 
            var opt = document.createElement('option');
            opt.value = i;
            opt.innerHTML = odgovor[i]["nazivGod"];
            select.appendChild(opt);
            
        }
    

})
	}