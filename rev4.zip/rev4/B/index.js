const express = require('express');
var bodyParser = require('body-parser');
const app = express();  
const fs = require('fs');
const multer = require('multer');
const path = require('path');
const jsonxml = require('jsontoxml');
app.use(bodyParser.urlencoded({ extended: true })); // support encoded bodies
app.use(bodyParser.json()); // support json encoded bodies


//sync modele s bazom
const db = require('./db');
db.sequelize.sync();

function prepareErrorHtml(errorMessage) {
    return '<html><head><title>Greska</title></head><body>' + errorMessage + '</body></html>'
}


var nazivZadatka = ''; 
var storage = multer.diskStorage({
    destination: function (req, file, cb) {
      cb(null, 'uploads/')
    },
    filename: function (req, file, cb) {
      cb(null, req.body.naziv + path.extname(file.originalname))
    }
  });
  const upload = multer({ 
    storage: storage,
    fileFilter: function (req, file, callback) {
        var ext = path.extname(file.originalname);
        if(ext !== '.pdf') {
            req.fileValidationError = 'Samo pdf';
            return callback(null, false, new Error('Samo pdf'));
        }

        nazivZadatka = req.body.naziv;
        db.zadatak.findOne({where: {naziv: nazivZadatka}}).then(function(result){
            if(result != null) return callback(new Error("Ohani, zadatak vec postoji"));
            callback(null, true);
        }).catch(function(err) {
            console.log(err);
            return callback(new Error(err.errorMessage))
        });
}}).single('postavka');



///////////////// SPIRALA 4 /////////////////////////

// ZADATAK 2.a

app.post('/addVjezba', upload, (req, res) => {
    upload(req, res, err => {
        if(req.fileValidationError) {
            res.redirect('/greska.html');
        }
        else {
            db.godina.findOne({ where: { id: req.body.sGodine } }).then(godina => {
                db.vjezba.findOne({ where: { id: req.body.sVjezbe } }).then(vjezba => {
                    vjezba.addGodine(godina);
                    res.sendFile(__dirname + "\\public\\addVjezba.html");
                }).catch(function (err) {
                    res.send(err);
                });
            });
        }
    })
});


// 2.b ZADATAK

app.post('/addVjezba', upload, (req, res) => {
    upload(req, res , err => {
        if(req.fileValidationError) {
            res.redirect('/greska.html');
        }
        else {
            db.godina.findOne({ where: { id: req.body.sGodine } }).then(function(godina){
                if(godina == null) {
                    db.vjezba.create({
                        naziv: req.body.naziv,
                        spirala: req.body.spirala
                    }).then(function(vjezba){
                        console.log("Zadatak je uspjesno dodan.");
                        res.sendFile(__dirname + "\\public\\addVjezba.html");
                        vjezba.setGodine(godina);   
                    }).catch(function(err){
                        console.log(err);
                    });
                }
            }).catch(function(err){
                console.log(err);
            });
        }
    });
});



// 3. ZADATAK

app.get('/zadatak', function(req, res) {
    db.zadatak.findOne({ where: { naziv: req.query.naziv } }).then(function(result){
        var postavka = "http://localhost:8080/uploads/" + req.query.naziv + ".pdf"
        res.sendFile(`${__dirname}/uploads/${req.query.naziv}.pdf`);  
    }).catch(function(err){
        console.log("ERROR:  " + err);
    });
});


// 4. ZADATAK

app.post('/addGodina', upload, (req, res) => {
    upload(req, res, err => {
        if(req.fileValidationError) {
            res.redirect('/greska.html');
        }
        else {
            db.godina.create({
                nazivGod: req.body.nazivGod,    
                nazivRepSpi: req.body.nazivRepSpi,
                nazivRepVje: req.body.nazivRepVje
            }).then(function(result){
                console.log("Zadatak je uspjesno dodan.");
                res.sendFile(__dirname + "\\public\\addGodina.html");
            }).catch(function(err){
                console.log(err);
            });
        }
    });
});


// 5. zadatak

app.get('/godine', function(req, res) {
   db.godina.findAll({attributes: ['nazivGod', 'nazivRepSpi', 'nazivRepVje']}).then(function(result){
            if(result.length) {
                res.contentType("application/json");
                res.send(JSON.stringify(result));
            }
   }).catch(function(err){
       console.log("ERROR: " + err);
   });
});


// 2. ZADATAK
app.post('/addZadatak', upload, (req, res) => {
    upload(req, res, err => {
        if(req.fileValidationError) {
            res.redirect('/greska.html');
        }
        else {
            var enc = encodeURIComponent(nazivZadatka);
            db.zadatak.create({
                naziv: nazivZadatka,
                postavka: "http://localhost:8080/uploads/" + enc + ".pdf"
            }).then(function(result){
                console.log("Zadatak je uspjesno dodan.");
                res.sendFile(__dirname + "\\public\\addZadatak.html");
            }).catch(function(err){
                console.log(err);
            });
        }
    });
});

// 7. zadatak

function ucitajSveZadatkeUArrayJSON() {
    let rez = [];
    db.zadatak.findAll().then(function(result) {
        if(result.length) {
            rez.push(JSON.parse(result));
        }
    }).catch(function(err){
        console.log("ERROR: " + err);
    });
    return rez;
}

app.get('/zadaci', (req, res) => {
    switch(req.header('Accept')) {
        case 'json':
        case 'application/json':
            res.json(ucitajSveZadatkeUArrayJSON());
            break;
        case 'xml':
        case 'application/xml':
        res.type('application/xml');
            const xmlresult = jsonxml({
                zadaci:
                    ucitajSveZadatkeUArrayJSON().map(val => {
                        return {
                            name: 'zadatak',
                            children: {
                                naziv: val.naziv,
                                postavka: val.postavka
                            }
                        }
                    })
            });
            res.send('<?xml version="1.0" encoding="UTF-8"?>' + xmlresult);
            break;
        case 'csv':
        case 'text/csv':
            let result = '';
            let zadaci = ucitajSveZadatkeUArrayJSON();
            zadaci.forEach(zadatak => {
                result += `${zadatak.naziv},${zadatak.postavka}\r\n`; // ne znam da li se trazi br ili \r\n
            });
            res.type('text/csv');
            res.send(result);
            break;
        default:

    }
});

app.use(express.static('public'));

app.get('/', (req, res) => {
    res.redirect('/zadaci.html');
})

app.listen(8080, function() {
    console.log("Working on port 8080");
});


