function ValidirajSvaPolja1 (){
   
    var mojDiv=document.getElementById("greske");
    var validacija= new Validacija(mojDiv);
    var inputIme=document.getElementById("ime");
     validacija.ime(inputIme);
    
}
var listaStudenata;
var listaGodina;

function callback(err, response) {
    if (response != null) {listaStudenata = response;
    document.getElementsByName('dugme')[0].disabled = false;
    }
    if (err != null) alert(err)
}
function callbackGodina(response) {
    listaGodina = response;
}

function callbackAlert(response) {
    alert(JSON.parse(response).message);
}

var bbucket;

//funkcija koja se poziva u html-u addStudent
function KreirajInstancu() {
    var spinnerGod = document.getElementById("sGodine");
    var godinaSelect = spinnerGod.options[spinnerGod.selectedIndex].text;
    var key = document.getElementsByName("key")[0].value;
    var secret = document.getElementsByName("secret")[0].value;
    var nazivRepSpi;
    var nazivRepVje;
    for (var i=0; i<listaGodina.length; i++){
            if (listaGodina[i].naziv == godinaSelect) {
                nazivRepSpi = listaGodina[i].nazivRepSpi;
                nazivRepVje = listaGodina[i].nazivRepVje;
            }
    }
    if(!bbucket) 
        bbucket = new BitBucket(key, secret);
       try{
        bbucket.ucitaj(nazivRepSpi,nazivRepVje,callback);
       }catch(err){
        alert(err)
       }
    
   
}
function DobaviGodine() {
    var divGod=document.getElementById("god");
    //document.getElementsByName('dugme')[0].disabled = true;
    var godineAjax = new GodineAjax(divGod);
    godineAjax.dohvatiGodine(callbackGodina);
}

function SpajanjeGodineIStudenta() {
    var spinnerGod = document.getElementById("sGodine");
    var godinaSelect = spinnerGod.options[spinnerGod.selectedIndex].text;
   
    var studentJSON = {
        godina: godinaSelect, studenti: listaStudenata
    };

    bbucket.SpajanjeGodineIStudenta(studentJSON, callbackAlert);

}