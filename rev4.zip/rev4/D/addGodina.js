
function ValidirajSvaPolja(){
   
    var mojDiv=document.getElementById("greske");
    var validacija= new Validacija(mojDiv);
    var inputGodina=document.getElementById("godina");
    validacija.godina(inputGodina);
    var inputVjezba=document.getElementById("repozitorij_vjezba");
    validacija.repozitorij(inputVjezba, /^\w{1,5}$/);
    var inputSpirala=document.getElementById("repozitorij_spirala");
    validacija.repozitorij(inputSpirala, /^\w{1,5}$/);

}