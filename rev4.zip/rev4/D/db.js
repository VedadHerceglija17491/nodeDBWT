const Sequelize = require("sequelize");
const sequelize = new Sequelize("wt2018","root","root",{dialect:"mysql",logging:false});
const db = {};

db.Sequelize = Sequelize;
db.sequelize = sequelize;

//importovanje modela
db.student = sequelize.import(__dirname+'/student.js');
db.godina = sequelize.import(__dirname+'/godina.js');
db.zadatak = sequelize.import(__dirname+'/zadatak.js');
db.vjezba = sequelize.import(__dirname+'/vjezba.js');

//pravljenje medjutabela
db.godina.hasMany(db.student, {as:'studenti', foreignKey:'studentGod'});

db.godina_vjezba = db.godina.belongsToMany(db.vjezba, {through: 'godina_vjezba', as:'vjezbe', foreignKey: 'idgodina'});
db.vjezba.belongsToMany(db.godina, {through: 'godina_vjezba', as:'godine', foreignKey: 'idvjezba'});

db.vjezba_zadatak = db.vjezba.belongsToMany(db.zadatak, {through: 'vjezba_zadatak', as:'zadaci', foreignKey: 'idvjezba'});
db.vjezba_zad = sequelize.define('vjezba_zadatak',{})
db.zadatak.belongsToMany(db.vjezba, {through: 'vjezba_zadatak', as:'vjezbe', foreignKey: 'idzadatak'});

module.exports = db