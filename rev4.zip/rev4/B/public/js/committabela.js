var CommitTabela = (function() {
    //lokalne variable idu ovdje

    var tabelaObj = {};

    var najviseKolona = 0;

    var naslovCommitiDom;
    
    var konstruktor = function(divElement, brojZadataka) {
        var beginOutput = `
            <table> 
                <thead>
                    <tr>
                        <td>
                            Naziv zadatka
                        </td>
                        <td id="naslovCommiti">
                            Commiti
                        </td>
                    </tr>
                </thead>
        `;

        var endOutput = '</table>';

        var content = '';

        if (brojZadataka >= 0) {
            content += '<tbody>';
            for(var i = 0; i < brojZadataka; i++) {
                content += '<tr><td>Zadatak ' + (i + 1) + '</td></tr>';
                tabelaObj['zadatak' + (i + 1)] = {
                    brojKolona: 0,
                    brojCommitova: 0
                }
            }
            content += '</tbody>';
        }

        var output = beginOutput + content + endOutput;
        // console.log(tabelaObj);
        divElement.innerHTML = output;

        for(var i = 0; i < brojZadataka; i++) {
            tabelaObj['zadatak' + (i + 1)].domElement = divElement.querySelector(`tbody > tr:nth-of-type(${i + 1})`);
            // console.log(`#mojDiv tbody > tr:nth-of-type(${i + 1})`);
            // console.log(tabelaObj['zadatak' + (i + 1)].domElement = divElement.querySelector(`tbody > tr:nth-of-type(${i + 1})`));
        }

        // inicijalizacije

        naslovCommitiDom = document.getElementById('naslovCommiti');

        return {
             dodajCommit: function(rbZadatka, url) {
                if (rbZadatka < brojZadataka) {
                    rbZadatka++;
                    let zadatakCurrent = tabelaObj['zadatak' + rbZadatka];

                    // ************************************
                    // slucaj kada samo dodajemo td ali ne prosirujemo red
                    // ************************************

                    // console.log(tabelaObj);
                    // console.log(zadatakCurrent.domElement);

                    if (zadatakCurrent.brojKolona - 1 === zadatakCurrent.brojCommitova) {
                        // console.log('uso, zadatak: ' + rbZadatka);
                        // console.log(zadatakCurrent.domElement);
                        
                        // if (zadatakCurrent.brojCommitova === 0) {
                            let lastTd = zadatakCurrent.domElement.querySelector("td:last-of-type");
                            if (lastTd.getAttribute('colspan') > 1) {
                                lastTd.removeAttribute('colspan');
                                lastTd.innerHTML = `<a href="${url}">${zadatakCurrent.brojKolona}</a>`;
                                zadatakCurrent.domElement.innerHTML += `<td colspan="${najviseKolona - zadatakCurrent.brojKolona}"></td>`;
                                zadatakCurrent.brojKolona++;
                            } else {
                                lastTd.removeAttribute('colspan');
                                lastTd.innerHTML = `<a href="${url}">${zadatakCurrent.brojKolona}</a>`;
                            }
                            
                            
                            // zadatakCurrent.domElement.innerHTML += `<td colspan="${najviseKolona - zadatakCurrent.brojKolona}"></td>`
                        // } else {
                        //     zadatakCurrent.domElement.querySelector("td:last-of-type").innerHTML = `<a href="${url}">${zadatakCurrent.brojKolona}</a>`;
                        // }

                        zadatakCurrent.brojCommitova++;
                    }

                    // ************************************
                    // slucaj kada dodajemo novi commit u vec najduzi red
                    // ************************************
                    else if (++zadatakCurrent.brojCommitova > najviseKolona) {
                        // console.log("uso drugi, zadatak: " + rbZadatka);
                        zadatakCurrent.brojKolona++;
                        // zadatakCurrent.brojCommitova++;

                        zadatakCurrent.domElement.innerHTML += `<td><a href="${url}">${zadatakCurrent.brojKolona}</a></td>`;

                        najviseKolona = zadatakCurrent.brojKolona;

                        for (let zadatak in tabelaObj) {
                            if (tabelaObj.hasOwnProperty(zadatak)) {
                                // console.log(tabelaObj[zadatak]);
                                let zadatakObj = tabelaObj[zadatak];
                                if (zadatakObj != zadatakCurrent) {
                                    
                                    let razlika = najviseKolona - zadatakObj.brojCommitova;
                                    if (zadatakObj.brojKolona > 0 && zadatakObj.brojCommitova < zadatakObj.brojKolona) {
                                        // console.log('test2');
                                        zadatakObj.domElement.querySelector('td:last-of-type').setAttribute('colspan', najviseKolona);
                                        
                                    } else {
                                        // console.log('test');
                                        zadatakObj.domElement.innerHTML += `<td colspan=${razlika}></td>`;
                                        tabelaObj[zadatak].brojKolona++;
                                        // console.log(zadatakObj);
                                    }
                                    // mozda ima greska ako je zadnja kolona zapravo commit; TODO: check       
                                }
                            }
                        }
                        // console.log('break');
                    }

                    // ************************************
                    // prosirivanje naslova
                    // ************************************
                    if (najviseKolona > 1 && naslovCommitiDom != najviseKolona) {
                        naslovCommitiDom.setAttribute('colspan', najviseKolona);
                    }
                    return 1;
                }

                return -1;
             },
             editujCommit: function(rbZadatka, rbCommita, url) {
                if (rbZadatka < 0 || rbZadatka >= Object.keys(tabelaObj).length) {
                    return -1;
                }
                let zadatakCurrentObj = tabelaObj['zadatak' + (rbZadatka + 1)];

                if (rbCommita >= zadatakCurrentObj.brojCommitova || rbCommita < 0) {
                    return -1;
                }

                zadatakCurrentObj.domElement
                    .querySelector(`td:nth-of-type(${rbCommita + 2}) a`)
                    .setAttribute('href', url == '' ? '#' : url);

                return 1;
             },
             obrisiCommit: function(rbZadatka, rbCommita) {
                //  console.log(Object.keys(tabelaObj).length);
                if (rbZadatka < 0 || rbZadatka >= Object.keys(tabelaObj).length) {
                    return -1;
                }
                let zadatakCurrentObj = tabelaObj['zadatak' + (rbZadatka + 1)];

                if (rbCommita >= zadatakCurrentObj.brojCommitova || rbCommita < 0) {
                    return -1;
                }

                zadatakCurrentObj.brojCommitova--;

                var kolonaDom = zadatakCurrentObj.domElement.querySelector(`td:nth-of-type(${rbCommita + 2})`);

                var zadnjaKolonaDom = zadatakCurrentObj.domElement.querySelector(`td:last-of-type`);

                if (kolonaDom === zadnjaKolonaDom) {
                    kolonaDom.innerHTML = '';
                } else {
                    zadatakCurrentObj.domElement.removeChild(kolonaDom);
                    if (zadnjaKolonaDom.textContent == '') {
                        zadnjaKolonaDom.setAttribute('colspan', zadnjaKolonaDom.getAttribute('colspan') + 2);
                    } else {
                        zadatakCurrentObj.domElement.innerHTML += `<td></td>`;
                    }
                    zadatakCurrentObj.brojKolona--;
                }

                let trebaIzbacitiZadnjuKolonuSvima = true;

                for (let zadatak in tabelaObj) {
                    if (tabelaObj.hasOwnProperty(zadatak)) {
                        // console.log(tabelaObj[zadatak]);
                        let zadatakObj = tabelaObj[zadatak];
                        if (zadatakObj.brojCommitova >= najviseKolona) {
                            trebaIzbacitiZadnjuKolonuSvima = false;
                        }
                    }
                }

                if (trebaIzbacitiZadnjuKolonuSvima) {
                    najviseKolona--;
                    for (let zadatak in tabelaObj) {
                        if (tabelaObj.hasOwnProperty(zadatak)) {
                            // console.log(tabelaObj[zadatak]);
                            let zadatakObj = tabelaObj[zadatak];
                            let tempKolonaZadnja = zadatakObj.domElement.querySelector(`td:last-of-type`);
                            if (tempKolonaZadnja.getAttribute('colspan') > 1) {
                                tempKolonaZadnja.setAttribute('colspan', tempKolonaZadnja.getAttribute('colspan') - 1);
                            } else {
                                zadatakObj.domElement.removeChild(tempKolonaZadnja);
                                zadatakObj.brojKolona--;
                            }
                            
                        }
                    }
                }

                return 1;
             }
        }
    }
    return konstruktor;
}());