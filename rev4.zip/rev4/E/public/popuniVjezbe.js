function popuniVjezbe() {
    var ajax = new XMLHttpRequest();

    var  selekt=document.getElementsByName("sVjezbe")[0];
    var  selekt1=document.getElementsByName("sVjezbe")[1];
    ajax.onreadystatechange = function() {
        if(ajax.readyState == 4 && ajax.status == 200) { 

            var nizVjezbe = JSON.parse(ajax.responseText);
          
            for(var i=0; i<nizVjezbe.length; i++) {
                var option = document.createElement("option");
                option.value=nizVjezbe[i].id;
                 option.text = nizVjezbe[i].naziv;   
                var option1 = document.createElement("option");
                option1.value = nizVjezbe[i].id;
                option1.text = nizVjezbe[i].naziv;            
                selekt.appendChild(option);
                selekt1.appendChild(option1);
            }

        }
        if(ajax.readyState == 4 && ajax.status == 404) {
            document.write = "Greska";
        }
    }
    ajax.open('GET', 'http://localhost:8080/vjezbe', true);
    ajax.send();
}