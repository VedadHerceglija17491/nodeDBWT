function ValidirajSvaPolja (){
    var mojDiv=document.getElementById("greske");
    var validacija= new Validacija(mojDiv);
    var inputNaziv=document.getElementById("naziv");
    return validacija.naziv(inputNaziv);
    
}