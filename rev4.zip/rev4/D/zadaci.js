function ValidirajSvaPolja() {
    var mojDiv=document.getElementById("greske");
    var validacija= new Validacija(mojDiv);
    var inputIme=document.getElementById("imena_studenata");
    validacija.ime(inputIme);
}
