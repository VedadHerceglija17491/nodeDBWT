function popuniGodineStudenti() {
    var ajax = new XMLHttpRequest();

    var  selekt=document.getElementsByName("sGodina");
    ajax.onreadystatechange = function() {
        if(ajax.readyState == 4 && ajax.status == 200) { 

            var nizGodine = JSON.parse(ajax.responseText);
            for(var i=0; i<nizGodine.length; i++) {
                var option = document.createElement("option");
               
               
                option.value=nizGodine[i].id; 
                 option.text = nizGodine[i].nazivGod;    
                    
                selekt[0].appendChild(option);
               
             
                
            }

        }
        if(ajax.readyState == 4 && ajax.status == 404) {
            document.write = "Greska";
        }
    }
    ajax.open('GET', 'http://localhost:8080/godine', true);
    ajax.send();
}