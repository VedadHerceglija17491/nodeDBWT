function prva() {
    var ajax = new XMLHttpRequest();
    var selekt = document.getElementsByName("sGodine")[0];
    var selekt1=document.getElementsByName("sGodine")[1];
    ajax.onreadystatechange = function() {
        if(ajax.readyState == 4 && ajax.status == 200) { 
            var nizGodine = JSON.parse(ajax.responseText);

            for(var i=0; i<nizGodine.length; i++) {
                var option = document.createElement("option");
                option.value = option.text = nizGodine[i].nazivGod;               
                selekt.add(option);
              
            }
            var nizGodine2 = JSON.parse(ajax.responseText);

            for(var i=0; i<nizGodine2.length; i++) {
                var option1 = document.createElement("option");
                option1.value = option1.text = nizGodine2[i].nazivGod;               
                selekt1.add(option1);
               
            }

        }
        if(ajax.readyState == 4 && ajax.status == 404) {
            document.write = "Greska";
        }
    }
    console.log("tusam")

    ajax.open('GET', 'http://localhost:8080/godine', true);
    ajax.send();
}