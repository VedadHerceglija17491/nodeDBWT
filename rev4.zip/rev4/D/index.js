const express = require('express');
const fs = require('fs');
const app = express();
const bodyParser = require('body-parser');
var path = require('path')
var URL= require('url');
var multer = require('multer');
const directoryPath = path.join(__dirname, '');
var jsonxml = require('json2xml');

//definisanje baze
const db = require('./db.js');
db.sequelize.sync();

var storage = multer.diskStorage({
    destination: function(req, file, callback) {
        callback(null, '');
    },
    filename: function(req, file, callback) {
        let tijelo = req.body;

        let imePolja = tijelo['naziv'];
        callback(null, imePolja+".pdf");
       
    }
})
    
var upload = multer({storage: storage, fileFilter: function(req, file, callback){
    if(req.body["naziv"]=="") {
        return callback(null, false);
    }
    return callback(null, true);
}}, {dest:'./uploads/'});
//var upload = multer({dest:'./uploads/'});
app.use(express.static(path.join(__dirname, '')));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

//prvi zadatak
app.get('',function(request,response){
   // console.log('./'+request.url);
    switch(request.method) {
        case 'GET':
        
        fs.readFile('./'+request.url, 'utf-8', function (err, html) {
            
            if (err) {
                throw err; 
            } 
            response.writeHead(200, {"Content-Type": "text/html"});  
            response.write(html);  
            response.end();
        });
        break
    }
});

//drugi zadatak - popravljen sa bazom
app.post("/addZadatak",upload.single('postavka'), function(req, res, next){
    let tijelo = req.body;
    let imePolja = tijelo['naziv'];

    //isot ko i na spirali 3
    if( imePolja=="" || req.file==null ) {
       
        fs.readFile('./greska.html', 'utf-8', function (err, html) {
            if (err) {
                throw err; 
            } 
            res.writeHead(200, {"Content-Type": "text/html"});  
            if(req.file==null) res.write("<h3>Niste unijeli sva polja!</h3>");
            else if(imePolja=="" ) res.write("<h3>Niste unijeli sva polja!</h3>");
           
            res.write(html);  
            res.end();
        });
    }
    else  {
        //pretrazivanje tabele zadaci
        db.zadatak.findOne({
            where: {
                naziv: imePolja
            }
        }).then(function(naziv) {
            console.log("Callback")
            
            if (naziv) {
                console.log("Postoji")
                fs.readFile('./greska.html', 'utf-8', function (err, html) {
                    if (err) {
                        throw err; 
                    } 
                    res.writeHead(200, {"Content-Type": "text/html"});  
                    if(path.extname(req.file.originalname) != '.pdf') res.write("<h3>Ovo nije pdf file!</h3>");
                    else res.write("<h3> Postoji zadatak sa istim imenom!</h3>");
                    
                    res.write(html);  
                    res.end();
                });
            } else {
                console.log("Ne postoji")

                //upisivanje u tabelu zadaci 
                db.zadatak.create({naziv:imePolja,postavka:"localhost:8080/"+imePolja+".pdf"});
                res.redirect('./addZadatak.html');
            }

        }).catch(function(err) {
            console.log(err)
        })
    }
});

//treci zadatak - popravljen sa bazom
app.get('/zadatak',function(req,res){
    
    var url1 = URL.parse(req.url);
    var parametar = new URL.URLSearchParams(url1.query);
    var imePolja=parametar.get("naziv").toString();
    db.zadatak.findOne({
        where: {
            naziv: imePolja
        }
    }).then(function(zadatak) {
        
        if (!zadatak) {
           
            fs.readFile('./greska.html', 'utf-8', function (err, html) {
                if (err) {
                    throw err; 
                } 
                res.writeHead(200, {"Content-Type": "text/html"});  
                if(path.extname(req.file.originalname) != '.pdf') res.write("<h3>Ovo nije pdf file!</h3>");
                else res.write("<h3> Postoji zadatak sa istim imenom!</h3>");
                
                res.write(html);  
                res.end();
            });
        } else {
            
            res.redirect('./'+zadatak.naziv+".pdf");
        }

    }).catch(function(err) {
        console.log(err)
    })

});

//cetvrti zadatak - popravljen sa bazom
app.post('/addGodina',function(req,res){

    if(req.body.nazivGod=="" || req.body.nazivRepSpi=="" || req.body.nazivRepVje=="") {
        fs.readFile('./greska.html', 'utf-8', function (err, html) {
        if (err) {
            throw err; 
        } 
        res.writeHead(200, {"Content-Type": "text/html"}); 
        res.write("<h3> Niste unijeli sva polja!</h3>");
        res.write(html);  
        res.end();
        
    });}
    else {

    db.godina.findOne
    ({
        //uslov
        where: {
            naziv: req.body.nazivGod
        }
    }).then(function(godina) {

        if (godina) {
           
            fs.readFile('./greska.html', 'utf-8', function (err, html) {
                if (err) {
                    throw err; 
                } 
                res.writeHead(200, {"Content-Type": "text/html"}); 
                res.write("<h3> Postoji godina sa istim imenom!</h3>");
                
                res.write(html);  
                res.end();
            });
        } else {
            //upisivanje u tabelu godina
            db.godina.create({naziv: req.body.nazivGod, nazivRepSpi: req.body.nazivRepSpi ,nazivRepVje: req.body.nazivRepVje}).then(function (godina) { 
                res.redirect('./addGodina.html');
            }).catch(function(err){
             console.log(err);
            })
            
        }

    }).catch(function(err) {
        console.log(err)
    })
}
    
});
//peti zadatak - popravljen sa bazom
app.get('/godine',function(req,response){
   
    db.godina.findAll().then(function(godine) {
        
        if (!godine) {
            console.log("nema godine");
        } else {
        
            response.writeHead(200, {'Content-Type': "application/json"});
            response.end(JSON.stringify(godine));
       
        }

    }).catch(function(err) {
        console.log(err)
    })

});

//pomocni zahtjev za dohvacanje listi vjezbi iz baze
app.get('/vjezbe',function(req,response){
   
    db.vjezba.findAll().then(function(vjezbe) {
        
        if (!vjezbe) {
            console.log("nema vjezbi");
        } else {
        
            response.writeHead(200, {'Content-Type': "application/json"});
            response.end(JSON.stringify(vjezbe));
       
        }

    }).catch(function(err) {
        console.log(err)
    })

});

//ovo je na pocetku bilo za testiranje zadatka 3., ali se vise ne koristi!!!
app.get('/studenti',function(req,response){
   
    //za prvobitnu provjeru
    var HarkodiranaListStudenta = 
    [
        {imePrezime: "Neko", index: "12"},
        {imePrezime: "Hamo", index: "2"},
        {imePrezime: "Kruskica", index: "1"}
    ];
    
    response.writeHead(200, {'Content-Type': "application/json"});
    response.end(JSON.stringify(HarkodiranaListStudenta));


});
//url koristen da bi pri selektovanju vjezbe dohvatili nove zadatke vezane za vjezbu
app.get('/dohvatiZadatke/:idVje',function(req,response){
   
    db.zadatak.findAll().then(function(zadaci) {
        
        db.vjezba_zad.findAll().then(function(vjezbezadaci){
            var listaZadatakaKojiNisuPovezani = [];
            for(var i=0; i<zadaci.length; i++) {
                var spojen = false;
                for(var j=0; j<vjezbezadaci.length; j++) {
                    if (zadaci[i].id == vjezbezadaci[j].idzadatak && vjezbezadaci[j].idvjezba == req.params.idVje) {
                        spojen = true;
                        break;  
                    }
                }
                if (!spojen) {
                    listaZadatakaKojiNisuPovezani.push(zadaci[i]);
                }
            }
        
            response.writeHead(200, {'Content-Type': "application/json"});
            response.end(JSON.stringify(listaZadatakaKojiNisuPovezani));
       
        })
    }).catch(function(err) {
        console.log(err)
    })

});
//pomocna funkcija
function callback(listaStudenata, godina, brojDodanihStudenata, ukupanBrojStudenata, response) {
    db.godina.findOne({
        where :{
            naziv: godina
        }
    }).then(function(godinaBaza) {   
        db.student.findAll().then(function(studenti) {         
            var lista = []
            for (var i=0; i<studenti.length; i++) {
                for (var j=0; j<listaStudenata.length; j++) {
                    if (studenti[i].index == listaStudenata[j].index){
                        lista.push(studenti[i])
                        break;
                    }
                }
            }
            godinaBaza.setStudenti(lista).then(function() {
                var json =  {
                    message:"Dodano je "+brojDodanihStudenata+ " novih studenata i upisano " +ukupanBrojStudenata+" na godinu "+ godina
                }
                response.writeHead(200, {'Content-Type': "application/json"});
                response.end(JSON.stringify(json));
                
            }).catch(function(err){
                console.log(err)
            })

        })
    })
}
//zadatak 3.a i b
app.post('/student',function(req,response){
   
    var godina = req.body.godina;
    var listaStudenata = req.body.studenti;
    var brojDodanihStudenata = 0;
    var ukupanBrojStudenata = listaStudenata.length;
    var brojStudenataZaDodati = 0;
   
    db.student.findAll().then(function(studenti) {

        for (var i=0; i<listaStudenata.length; i++) {
            var postoji = false;
            for (var j=0; j<studenti.length; j++) {
                if(listaStudenata[i].index==studenti[j].index) {
                    postoji = true;
                    break;
                }
            }
            if (!postoji){
                brojStudenataZaDodati++;
                
        }
    }
        for (var i=0; i<listaStudenata.length; i++) {
            var postoji = false;
            for (var j=0; j<studenti.length; j++) {
                if(listaStudenata[i].index==studenti[j].index) {
                    postoji = true;
                    break;
                }
            }
            if (!postoji){
                brojDodanihStudenata++;
                db.student.create({imePrezime: listaStudenata[i].imePrezime, index: listaStudenata[i].index}).then(function(student){
                    
                    if (brojDodanihStudenata == brojStudenataZaDodati)
                    callback(listaStudenata,godina,brojDodanihStudenata,ukupanBrojStudenata,response)
                    
                })
                if (brojDodanihStudenata == brojStudenataZaDodati) break;
            }
     
        }
    
        if (brojDodanihStudenata == 0) {
            callback(listaStudenata,godina,brojDodanihStudenata,ukupanBrojStudenata,response)
        }
    })
    

});
//sedmi zadatak - popravljen sa bazom
app.get('/zadaci',function(req,res){
    var responseType;
    var acceptTypes = req.headers["accept"].split(", ");
  
    if(acceptTypes.includes('application/json') )  {
        
        res.setHeader('Content-Type', 'application/json')
        responseType = "JSON"
    }
    else if(acceptTypes.includes('application/xml'))  {
       
        res.setHeader('Content-Type', 'application/xml')
        responseType = "XML"
    }
    else if(acceptTypes.includes('text/xml'))  {
       
        res.setHeader('Content-Type', 'text/xml')
        responseType = "XML"
    }
    else if(acceptTypes.includes('text/csv'))  {
        
        res.setHeader('Content-Type', 'text/csv')
        responseType = "CSV"
    }
    else {
         
        res.setHeader('Content-Type', 'application/json')
        responseType = "JSON"
    }

        db.zadatak.findAll().then(function (niz) {
            switch (responseType) {

                case "JSON":
                    res.end(JSON.stringify(niz))
                    break;
                case "XML":
                    var noviJson = [];
                    for(var i=0; i<niz.length; i++) {
                        noviJson.push({zadatak : {naziv: niz[i].naziv, postavka: niz[i].postavka}})
                    }
                    res.end(jsonxml({ 'zadaci': noviJson}, { header: true }));
                    break;
                case "CSV":
                var string="";
                    for(var i=0; i<niz.length; i++ ) {
                        string += niz[i].naziv +","+ niz[i].postavka+"\n";
                    }
                    res.end(string)
                    break;
            }
    
        })

});


//zadatak 2.a i b (spirala 4)

app.post('/addVjezba',function(req,res){

   //vrsi se provjera da li postoji checkbox, u svrhu prepoznavanja sa koje forme je poslan zahtjev
    if(typeof req.body.oznacen==="undefined") {
    
        var godina = req.body.nazivGod
        var vjezba = req.body.nazivVje

        
        db.godina.findOne
        ({
            where: {
                naziv: godina
            }
        }).then(function(godina) {

            db.vjezba.findOne({
                where : {
                    naziv: vjezba
                }
            }).then(function(vjezba){
                godina.addVjezbe(vjezba);
            })
            
        }).catch(function(err) {
            console.log(err)
        })
    }

    else {

        //unosenje iz forme u tableu godine
    
     db.vjezba.create({naziv: req.body.nazivVje, spirala:  req.body.oznacen}).then(function (vjezba) { 
        db.godina.findOne
    ({
        where: {
            naziv: req.body.nazivGod
        }
    }).then(function(godina) {

        godina.addVjezbe(vjezba).then(function(vjezba){
            console.log("dodano")
            res.redirect("./addVjezba.html");
        })
        
    })
    

    }).catch(function(err){
        console.log("err");
    })
    
    }

});


//zadatak 2.c (spirala 4)
app.post('/vjezba/:idVjezbe/zadatak',function(req,res){
    
    var zadatak = req.body.nazivZad;
    var idVjezbe = req.params.idVjezbe

    
    db.zadatak.findOne
    ({
        where: {
            naziv: zadatak
        }
    }).then(function(zadatak) {

        db.vjezba.findOne({
            where : {
                id: idVjezbe
            }
        }).then(function(vjezba){
            zadatak.addVjezbe(vjezba);
        }).catch(function(err){
            console.log(err)
        })
        
    }).catch(function(err) {
        console.log(err)
    })


});
app.listen(8080);


