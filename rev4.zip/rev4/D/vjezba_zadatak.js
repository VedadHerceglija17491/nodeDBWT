const Sequelize = require("sequelize");

module.exports = function(sequelize,DataTypes){
    
    const VjezbaZad = sequelize.define('vjezba_zadatak',{})
    return VjezbaZad;
}