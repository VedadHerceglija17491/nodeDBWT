
function ValidirajSvaPolja() {
    var mojDiv=document.getElementById("greske");
    var validacija= new Validacija(mojDiv);
    var inputIme=document.getElementById("username");
    validacija.ime(inputIme);
    var inputPassword=document.getElementById("password");
    validacija.password(inputPassword);
    
}
