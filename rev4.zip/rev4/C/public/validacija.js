var Validacija=(function(){
    var godina="";
    var indeks="";
    var repozitorij="";
    var password="";
    var naziv="";
    var poruka="Sljedeća polja nisu validna:";
    var proba="";
    var konacno="";
    var brojac=0;
    var konstruktor=function(divElementPoruke){
      
    return{
        
        godina: function(inputElement){ 
            var string=inputElement.value;
            if((/\d{4}\/\d{4}/).test(string)) {
                var i=0;
                var brojac1=0;
                var brojac2=0;
               
                console.log(brojac2);
                var broj1=string.substr(0,2);
                var broj2=string.substr(5,2);
                var a1=parseInt(broj1);
                var b1=parseInt(broj2);
                if(a1!=20 || b1!=20) {
                   godina= "godina,";
                   inputElement.style.backgroundColor="oranged";
                
                }

               var prvi= string.substr(0,4);
               var drugi=string.substr(5,4);
               var a=parseInt(prvi);
               var b=parseInt(drugi);
               if(a+1!=b) {
                godina= "godina,";
                
              
               }
               else { 
              
                godina= "";
               }
             }
            else {
              
            godina= "godina,";
             }

            
            var x=document.getElementById('poruka');
          
            
           if(godina=="" && indeks=="" && repozitorij=="" && password=="" && naziv=="") x.innerHTML="";
           else {
           proba=(poruka+godina+indeks+repozitorij+password+naziv);
           konacno=proba.substr(0,proba.length-1);
           x.innerHTML=konacno+"!";
           inputElement.style
           }

          
        },
        indeks: function(inputElement) {
            var broj=inputElement.value;
            if(!(/\d{5}/).test(broj)) {
         
            indeks="indeks,";
        }
        else {
            var pocetne=(broj/1000);
            if(pocetne<14 || pocetne>20) {
          
            indeks="indeks,";
            }
            else indeks="";
            
        }
        var x=document.getElementById('poruka');
       

        if(godina=="" && indeks=="" && repozitorij=="" && password=="" && naziv=="") x.innerHTML="";
           else {
           proba=(poruka+godina+indeks+repozitorij+password+naziv);
           konacno=proba.substr(0,proba.length-1);
           x.innerHTML=konacno+"!";
           }
    },
    repozitorij: function(inputElement,regex) {
        inputElement=inputElement.value;
        if(regex.test(inputElement)) { repozitorij=""; }
        else {
            repozitorij="repozitorij,";
        }
        var x=document.getElementById('poruka');
     

           if(godina=="" && indeks=="" && repozitorij=="" && password=="" && naziv=="") x.innerHTML="";
           else {
           proba=(poruka+godina+indeks+repozitorij+password+naziv);
           konacno=proba.substr(0,proba.length-1);
           x.innerHTML=konacno+"!";
           }
    },

    password: function(inputElement) {
        inputElement=inputElement.value;
        if(inputElement.length<8) password="password,";
        else if(inputElement.length>=8) {
        if((/[a-z]{2,}/).test(inputElement) && (/[A-Z]{2,}/).test(inputElement) && (/[0-9]{2,}/).test(inputElement)) { 
            for(var i=0; i<inputElement.length; i++) {
                if((inputElement[i]>='A' && inputElement[i]<='Z') || (inputElement[i]>='a' && inputElement[i]<='z') || (inputElement[i]>='0' && inputElement[i]<='9')){
                    if((inputElement[i]>='!' && inputElement[i]<='/') || (inputElement[i]>=58 && inputElement[i]<=64)) { password="password,";  console.log("tu"); break;   }
                     else {password=""; }
                    
                }
               
            }
        }
        else { password="password,";  }
    }
        
    
        
        var x=document.getElementById('poruka');
     

           if(godina=="" && indeks=="" && repozitorij=="" && password=="" && naziv=="") x.innerHTML="";
           else {
           proba=(poruka+godina+indeks+repozitorij+password+naziv);
           konacno=proba.substr(0,proba.length-1);
           x.innerHTML=konacno+"!";
           }
    },

    naziv: function(inputElement) {
        inputElement=inputElement.value;
        if(inputElement.length<3) naziv="naziv,";
        if(!((/^[A-Z]/).test(inputElement)) && !((/^[a-z]/).test(inputElement))) { naziv="naziv,"; brojac++;}
        else if((/^[A-Z]/).test(inputElement) || (/^[a-z]/).test(inputElement)) {
            if((/\d$/).test(inputElement) || (/[a-z]$/).test(inputElement)) {
                
                for(var i=0; i<inputElement.length;i++) {
                if(!((/[/"'!?:;,-\\]/).test(inputElement[i])) && !((/[a-zA-Z0-9]/).test(inputElement[i]))) {
                    naziv="naziv,";
                    console.log("da");
                    brojac++;
                    break;
                    
                }
                else brojac=0; 
            }
        }
            
        }
        if(!((/\d$/).test(inputElement)) && !((/[a-z]$/).test(inputElement))) {naziv="naziv,"; brojac++; }
        if(brojac==0 && inputElement.length>3) naziv="";
        console.log(naziv);
        var x=document.getElementById('poruka');
     

           if(godina=="" && indeks=="" && repozitorij=="" && password=="" && naziv=="") x.innerHTML="";
           else {
           proba=(poruka+godina+indeks+repozitorij+password+naziv);
           konacno=proba.substr(0,proba.length-1);
           x.innerHTML=konacno+"!";
           }
    }

    }
    
}
return konstruktor;
} ());
/*function validirajIndex(){
    var mojDiv=document.getElementById("poruka");
    var input = document.getElementById("text2");
    var x=new Validacija(mojDiv);
    x.indeks(input);
//	return x(document.getElementById('text2').value);
}
function pokreni() {
	var dTabela;
	var nasaTabela;
	var mojDiv=document.getElementById("div");
	var input = document.getElementById("lakilak");
	var validacija = new Validacija(mojDiv);
	validacija.index(input);
	
}
function validirajGodinu(){
	var mojDiv=document.getElementById("poruka");
    var input = document.getElementById("text1");
    var x=new Validacija(mojDiv);
    x.password(input);
}

function validirajRepozitorij(){
	var x=Validacija.repozitorij;
	return x(document.getElementById('text3').value,(/\d/));
}

function validirajPassword(){
	var x=Validacija.password;
	return x(document.getElementById('text3').value);
}

function validirajNaziv() {
    var mojDiv=document.getElementById("poruka");
    var input = document.getElementById("text3");
    var x=new Validacija(mojDiv);
    x.naziv(input);
}*/