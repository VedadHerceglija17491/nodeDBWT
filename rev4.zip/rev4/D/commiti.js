var tabela;
function KreirajTabelu() {
    
   var mojDiv = document.getElementsByClassName("glavni")[0];
    tabela = new CommitTabela(mojDiv, 6);
}

function Funkcija ()
{  
    var vrijednostBroja = document.getElementById("broj1").value;
    tabela.dodajCommit(vrijednostBroja,"https://c2.etf.unsa.ba/pluginfile.php/85336/mod_resource/content/1/Spirala%202%20WT%202018_19.pdf"); 
}


function Funkcija1 ()
{  
    var vrijednostBroja1 = document.getElementById("broj2").value;
    var vrijednostBroja2 = document.getElementById("broj4").value;
    tabela.obrisiCommit(vrijednostBroja1, vrijednostBroja2);
}
function Funkcija2 ()
{  
    var vrijednostBroja1 = document.getElementById("broj3").value;
    var vrijednostBroja2 = document.getElementById("broj5").value;
    tabela.editujCommit(vrijednostBroja1, vrijednostBroja2, "https://docs.google.com/document/d/1P2wjLwWHuEOWI1dAFCu8_lxZiGSsoltZ8Bv1gJedYhU/edit" );
}