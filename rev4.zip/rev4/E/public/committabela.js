var CommitTabela=(function(){
    //lokalne variable idu ovdje
    
    var konstruktor=function(divElement,brojZadataka){
        var i=0, rowEl=null,
        tabela = document.createElement('TABLE');
        tabela.setAttribute("border", 1);
        // create 10 table rows, each with two cells
        var red=tabela.insertRow();
        red.insertCell().textContent="Zadaci";
        red.insertCell().textContent="Commiti";
      
      //kreiranje redova
        for (i=1; i <= brojZadataka; i++) {
          rowEl = tabela.insertRow(); 
          rowEl.insertCell().textContent = "Zadatak "+i ;      
          rowEl.insertCell();      
        }
        divElement.appendChild(tabela);
    return{
        
    dodajCommit:function(rbZadatka,url){
       rbZadatka++;
       if(rbZadatka>tabela.rows.length-1) return -1; 
      var brojKomita=tabela.rows[rbZadatka].cells.length-1;
      
    // var broj= Number(tabela.rows[rbZadatka].cells[].getElementsByTagName("a")[0].innerHTML)  +1;
      var max=tabela.rows[0].cells.length; 
      for(var i=0; i<tabela.rows.length; i++)
    {
     
      if(tabela.rows[i].cells.length>max){
        max=tabela.rows[i].cells.length;
      }
    }
    if((tabela.rows[rbZadatka].cells.length == max) &&  (/^(\s|&nbsp;)*$/.test(tabela.rows[rbZadatka].cells[brojKomita].innerHTML)))
    {
      var broj=1;
      if((/^(\s|&nbsp;)*$/.test(tabela.rows[rbZadatka].cells[brojKomita].innerHTML))&& tabela.rows[rbZadatka].cells.length==2 )
      {
        broj=1;
      }
     
      else{
        broj= Number(tabela.rows[rbZadatka].cells[brojKomita-1].getElementsByTagName("a")[0].innerHTML)  +1;
      }
      
      tabela.rows[rbZadatka].cells[brojKomita].innerHTML='<a href="'+url+'">'+(broj).toString()+'</a>';
    }
    else if(tabela.rows[rbZadatka].cells.length == max)
    {
      var broj= Number(tabela.rows[rbZadatka].cells[brojKomita].getElementsByTagName("a")[0].innerHTML)  +1;

      tabela.rows[rbZadatka].insertCell().innerHTML='<a href="'+url+'">'+(broj).toString()+'</a>';
      tabela.rows[rbZadatka].cells[brojKomita].colSpan=1;
      for(var i=0; i<tabela.rows.length; i++)
      {
        var pomocna= tabela.rows[i].cells.length;
        if(i!=rbZadatka)
        { 
          tabela.rows[i].cells[pomocna-1].colSpan++;
        
        }
      }

      for(var i=1; i<tabela.rows.length; i++)
      {
        if(i!=rbZadatka && tabela.rows[i].cells.length==tabela.rows[rbZadatka].cells.length-1 && !(/^(\s|&nbsp;)*$/.test(tabela.rows[i].cells[brojKomita].innerHTML)))
        {
          tabela.rows[i].insertCell();
          tabela.rows[i].cells[tabela.rows[i].cells.length-2].colSpan--;
          tabela.rows[i].cells[tabela.rows[i].cells.length-1].colSpan++;
       }
      }
    
    }
    else {
      
      var razlika=max-tabela.rows[rbZadatka].cells.length;

      var broj=1;

      if(tabela.rows[rbZadatka].cells.length==2)
      {
        broj=1;
      }
      else {
        broj= Number(tabela.rows[rbZadatka].cells[brojKomita-1].getElementsByTagName("a")[0].innerHTML)  +1;

      }
      tabela.rows[rbZadatka].cells[brojKomita].innerHTML='<a href="'+url+'">'+(broj).toString()+'</a>';
     
      tabela.rows[rbZadatka].cells[brojKomita].colSpan=1;
      tabela.rows[rbZadatka].insertCell().colSpan+=razlika-1;

    }

    
    // bitno // tabela.rows[rbZadatka].cells[1].innerHTML ='<a href="'+url+'">'+(brojKomita).toString()+'</a>';

    },
    editujCommit:function(rbZadatka,rbCommita,url){


      if(rbZadatka>tabela.rows.length-2  ) return -1; 
     rbCommita++;
     rbZadatka++;
      if(rbCommita> tabela.rows[rbZadatka].cells.length-1 ) return -1;
      if(rbCommita==tabela.rows[rbZadatka].cells.length-1 && (/^(\s|&nbsp;)*$/.test(tabela.rows[rbZadatka].cells[tabela.rows[rbZadatka].cells.length-1].innerHTML))) return -1;

     var broj=Number(tabela.rows[rbZadatka].cells[rbCommita].getElementsByTagName("a")[0].innerHTML);


        tabela.rows[rbZadatka].cells[rbCommita].innerHTML='<a href="'+url+'">'+(broj).toString()+'</a>';

    },
    obrisiCommit:function(rbZadatka,rbCommita){
      if(rbZadatka>tabela.rows.length-2 ) return -1; 
      rbCommita++;
      rbZadatka++;
       if(rbCommita> tabela.rows[rbZadatka].cells.length-1 ) return -1;
       if(rbCommita==tabela.rows[rbZadatka].cells.length-1 && (/^(\s|&nbsp;)*$/.test(tabela.rows[rbZadatka].cells[tabela.rows[rbZadatka].cells.length-1].innerHTML))) return -1;
      
      var max=tabela.rows[0].cells.length; 
      for(var i=0; i<tabela.rows.length; i++)
    {
     
      if(tabela.rows[i].cells.length>max){
        max=tabela.rows[i].cells.length;
      }
    }
    
    var brojac=0;
    
    for(var i=1; i<tabela.rows.length; i++)
    {
      if(tabela.rows[i].cells.length==max && !(/^(\s|&nbsp;)*$/.test(tabela.rows[i].cells[tabela.rows[i].cells.length-1].innerHTML))) {brojac++;}
    }
    
      if(tabela.rows[rbZadatka].cells.length==max && brojac==1 && !(/^(\s|&nbsp;)*$/.test(tabela.rows[rbZadatka].cells[tabela.rows[rbZadatka].cells.length-1].innerHTML)) ){
        tabela.rows[rbZadatka].deleteCell(rbCommita);
          for(var i=0; i<tabela.rows.length; i++){

            if(i!=rbZadatka){
              var p=tabela.rows[i].cells[tabela.rows[i].cells.length-1].colSpan;
              console.log(p);
              if(tabela.rows[i].cells[tabela.rows[i].cells.length-1].colSpan==1){
                tabela.rows[i].deleteCell(tabela.rows[i].cells.length-1);

              }
              else{
                tabela.rows[i].cells[tabela.rows[i].cells.length-1].colSpan--;
              }
            }

          }

      }
      else if(tabela.rows[rbZadatka].cells.length==max && !(/^(\s|&nbsp;)*$/.test(tabela.rows[rbZadatka].cells[tabela.rows[rbZadatka].cells.length-1].innerHTML)) ){
        tabela.rows[rbZadatka].deleteCell(rbCommita);
        tabela.rows[rbZadatka].insertCell();
      }

      else{
        tabela.rows[rbZadatka].deleteCell(rbCommita);
        tabela.rows[rbZadatka].cells[tabela.rows[rbZadatka].cells.length-1].colSpan++;
      
      }
   
    }
    }
    
    }
    return konstruktor;
    }());
    
   function onLoad(){
      var mojDiv=document.getElementById("div");
      var nasaTabela= new CommitTabela(mojDiv,5);
    
   nasaTabela.dodajCommit(2,"nesto");
   nasaTabela.dodajCommit(2,"nesto");
   nasaTabela.dodajCommit(2,"nesto");
   nasaTabela.dodajCommit(2,"nesto");
   nasaTabela.dodajCommit(0,"nesto");
   nasaTabela.obrisiCommit(2,3);
   nasaTabela.dodajCommit(2,"nesto");
   nasaTabela.obrisiCommit(2,0);
   nasaTabela.dodajCommit(2,"nesto");
   nasaTabela.dodajCommit(0,"nesto");
   nasaTabela.dodajCommit(0,"nesto");
  // nasaTabela.dodajCommit(0,"nesto");
   nasaTabela.obrisiCommit(2,0);
   nasaTabela.editujCommit(2,2,"https://c2.etf.unsa.ba/");
    }