function ValidirajSvaPolja(){
   
    var mojDiv=document.getElementById("greske");
    var validacija= new Validacija(mojDiv);
    var inputNaziv=document.getElementById("naziv");
    validacija.naziv(inputNaziv);
    
}

var listaGodina;
var listaVjezbi;
var listaZadataka;
function godineCallback(response) {
    listaGodina = response;
}
function vjezbeCallback(response) {
    var divGod=document.getElementsByName("god")[0];
    var divGod1=document.getElementsByName("god")[1];
    var divVje=document.getElementsByName("vje")[0];
    var divVje1=document.getElementsByName("vje")[1];
    var divZad=document.getElementById("zad");

    var ajax = new VjezbeAjax(godineCallback, vjezbeCallback,zadaciCallback, divGod, divVje, divGod1, divVje1, divZad);
    listaVjezbi = response;
    var spinnerVje = document.getElementsByName("sVjezbe")[1];
    ajax.dohvatiZadatke(listaVjezbi[0].id)
    spinnerVje.onchange=(function(){
        var vjezba = spinnerVje.options[spinnerVje.selectedIndex].text;
        var idVjezbe = 0;
        
        for(var i=0; i<listaVjezbi.length; i++) 
            if(listaVjezbi[i].naziv==vjezba) 
                idVjezbe=listaVjezbi[i].id
    
        ajax.dohvatiZadatke(idVjezbe);
    })
    
}
function zadaciCallback(response) {
    listaZadataka = response;
}
function refresh(){
    document.location.reload();
}


function DohvatiGodineIVjezbeIZadatak() {
    
    var divGod=document.getElementsByName("god")[0];
    var divGod1=document.getElementsByName("god")[1];
    var divVje=document.getElementsByName("vje")[0];
    var divVje1=document.getElementsByName("vje")[1];
    var divZad=document.getElementById("zad");

    var ajax = new VjezbeAjax(godineCallback, vjezbeCallback,zadaciCallback, divGod, divVje, divGod1, divVje1, divZad);
    ajax.dohvatiGodine();
    ajax.dohvatiVjezbe();
    
}


function SpojiGodinuIVjezbu() {
    var spinnerGod = document.getElementsByName("sGodine")[0];
    var spinnerVje = document.getElementsByName("sVjezbe")[0];
    var godina = spinnerGod.options[spinnerGod.selectedIndex].text;
    var vjezba = spinnerVje.options[spinnerVje.selectedIndex].text;
    var idGodine = 0;
    var idVjezbe = 0;

    for(var i=0; i<listaGodina.length; i++) 
        if(listaGodina[i].naziv==godina) 
            idGodine=listaGodina[i].id;
        
    
    for(var i=0; i<listaVjezbi.length; i++) 
        if(listaVjezbi[i].naziv==vjezba) 
            idVjezbe=listaVjezbi[i].id;

            
    var divGod=document.getElementsByName("god")[0];
    var divGod1=document.getElementsByName("god")[1];
    var divVje=document.getElementsByName("vje")[0];
    var divVje1=document.getElementsByName("vje")[1];
    var divZad=document.getElementById("zad");
    var ajax = new VjezbeAjax(godineCallback, vjezbeCallback,zadaciCallback, divGod, divVje, divGod1, divVje1, divZad);
    ajax.spojiGodinuIVjezbu(godina, vjezba, refresh)   
}

function napraviNovuVjezbu(){
    var spinnerGod = document.getElementsByName("sGodine")[1];
    var nazivVjezbe = document.getElementById("naziv").value;
    var checked = document.getElementById("spirala").checked;
    
    var godina = spinnerGod.options[spinnerGod.selectedIndex].text;
            
    var divGod=document.getElementsByName("god")[0];
    var divGod1=document.getElementsByName("god")[1];
    var divVje=document.getElementsByName("vje")[0];
    var divVje1=document.getElementsByName("vje")[1];
    var divZad=document.getElementById("zad");
    var ajax = new VjezbeAjax(godineCallback, vjezbeCallback,zadaciCallback, divGod, divVje, divGod1, divVje1, divZad);
    ajax.napraviNovuVjezbu(godina, nazivVjezbe, checked, refresh)   
}
/////////////////////////////////////
function SpojiVjezbuIZadatak() {
    var spinnerVje = document.getElementsByName("sVjezbe")[1];
    var spinnerZad = document.getElementById("sZadatak");
    var zadatak = spinnerZad.options[spinnerZad.selectedIndex].text;
    var vjezba = spinnerVje.options[spinnerVje.selectedIndex].text;
    var idZadatka = 0;
    var idVjezbe = 0;

    for(var i=0; i<listaZadataka.length; i++) 
        if(listaZadataka[i].naziv==zadatak) 
            idZadatka=listaZadataka[i].id;
        
    
    for(var i=0; i<listaVjezbi.length; i++) 
        if(listaVjezbi[i].naziv==vjezba) 
            idVjezbe=listaVjezbi[i].id;

    
    var divGod=document.getElementsByName("god")[0];
    var divGod1=document.getElementsByName("god")[1];
    var divVje=document.getElementsByName("vje")[0];
    var divVje1=document.getElementsByName("vje")[1];
    var divZad=document.getElementById("zad");

    var ajax = new VjezbeAjax(godineCallback, vjezbeCallback,zadaciCallback, divGod, divVje, divGod1, divVje1, divZad);
    ajax.SpojiVjezbuIZadatak(idVjezbe, zadatak, refresh)   
}