const Sequelize = require("sequelize");
const sequelize = require("./db.js");
const GodinaVje = sequelize.define('godina_vjezba',{})

module.exports = function(sequelize,DataTypes){
    return GodinaVje;
}