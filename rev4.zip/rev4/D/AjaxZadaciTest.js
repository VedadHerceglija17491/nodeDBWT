
function callbackFn(response) {
    var mojDiv = document.getElementById("rep");
    mojDiv.innerHTML = JSON.stringify(response)
}
var ajax = new ZadaciAjax(callbackFn);
function Greska () {
    
    ajax.dajXML();
    ajax.dajCSV();
}
function dajXML () {
    ajax.dajXML();
}
function dajJSON () {
    ajax.dajJSON();
}
function dajCSV () {
    ajax.dajCSV();
}