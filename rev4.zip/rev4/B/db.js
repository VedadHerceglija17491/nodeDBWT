const Sequelize = require("sequelize");
const sequelize = new Sequelize('wt2018', 'root', 'root', {
    host: 'localhost',
    dialect: 'mysql',
    pool: {
        max: 5,
        min: 0,
        acquire: 30000,
        idle: 10000
    }
});
const db = {};

db.Sequelize = Sequelize;
db.sequelize = sequelize;

//models
db.student = sequelize.import(__dirname + '/student.js');
db.godina = sequelize.import(__dirname + '/godina.js');
db.zadatak = sequelize.import(__dirname + '/zadatak.js');
db.vjezba = sequelize.import(__dirname + '/vjezba.js');

//relations
db.godina.hasMany(db.student, {as:'studenti', foreignKey: 'studentGod'});
db.godinaVjezba = db.godina.belongsToMany(db.vjezba, {as: 'vjezbe', through: 'godina_vjezba', foreignKey: 'idgodina'});
db.vjezba.belongsToMany(db.godina, {as: 'godine', through: 'godina_vjezba', foreignKey: 'idvjezba'});
db.vjezbaZadatak = db.vjezba.belongsToMany(db.zadatak, {as: 'zadaci', through:'vjezba_zadatak', foreignKey: 'idvjezba'});
db.zadatak.belongsToMany(db.vjezba, {as: 'vjezbe', through: 'vjezba_zadatak', foreignKey: 'idzadatak'});

module.exports = db;