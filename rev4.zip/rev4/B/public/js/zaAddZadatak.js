document.addEventListener("DOMContentLoaded", function(){
    // Handler when the DOM is fully loaded
    validirajFormu('fPojedinacni', 'mojDivPoruke');
})